
/**
 * A utility class for IPD games
 * 
 * @author CSP1150 
 * @version 1
 */
public class IPD
{
    /**
     * How many dollars for the first player?
     * 
     * @param firstMove the first move
     * @param secondMove the second move
     * 
     * @return the payout for the first player
     */
    public static int getScore(char firstMove, char secondMove)
    {
        return 0;
    }
}
