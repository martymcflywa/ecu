// FileTasker.h

#ifndef FILETASKER_H
#define FILETASKER_H

#include <string>
using namespace std;

namespace FileTasker {
	const string filename = "db.txt";
	string myRead(string filename);
	int myWrite(string filename);
};

#endif