// FileTasker.cpp

#include <string>
#include <iostream>
#include <fstream>
#include "FileTasker.h"

using namespace std;

string FileTasker::myRead(string filename) {
	long begin, end, lineNumber;
	string record;
	cout << "I'm in reading mode.\n";
	ifstream myfile(filename);

	if (myfile.is_open()) {
		lineNumber = 0;
		while (!myfile.eof()) {
			getline(myfile, record);

			cout << "Line Number : " << lineNumber << " - " << record << endl;
			++lineNumber;
		};
		myfile.close();
		return record;
	}
	else cout << "Unable to open file";
	return 0;
}

int FileTasker::myWrite(string filename) {
	cout << "I'm in writing mode.\n";
	ofstream myfile(filename, ios::app);

	if (myfile.is_open()) {
		myfile << "You see I can write to your file.\n";
		myfile << "I can do it again.\n";
		myfile.close();
	}
	else cout << "Unable to open file";

	return 0;
}