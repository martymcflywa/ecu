#include <iostream>
#include <fstream>
#include <string>
#include "FileTasker.h"

using namespace std;
using namespace FileTasker;

int menuSelect();

int main() {
	int menuItem;
	menuItem = menuSelect();

	if (menuItem == 1) {
		myRead(filename);
		system("pause");
	}
	else if (menuItem == 2) {
		myWrite(filename);
		system("pause");
	}
}

int menuSelect() {
	int mItem;
	cout << "This is a little test for C++ file handling. \n" << "to read from a file, type(1) : \n" << "To write to a file, type(2) : \n";
	cin >> mItem;

	while (!(mItem == 1) && !(mItem == 2)) {
		cout << "Wrong selection, do you want to type again ? \nIf so, type(1) to read or(2) to write";
		cin >> mItem;

		if (!mItem == 1 && !mItem == 2);
	}
	return mItem;
}