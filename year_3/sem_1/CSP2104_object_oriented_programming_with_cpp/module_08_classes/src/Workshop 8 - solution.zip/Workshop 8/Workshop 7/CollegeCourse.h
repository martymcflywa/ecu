// CollegeCourse.h

#ifndef COLLEGECOURSE_H
#define COLLEGECOURSE_H

#include <string>

using namespace std;

class CollegeCourse {
private:
	string department;
	int courseNum;
	int seats;
public:
	void setDepartmentAndCourse(string, int);
	void setSeats(int);
	void displayCourseData();
};

#endif