// Main.cpp
// Task 1

#include <iostream>
#include <string>
#include "CollegeCourse.h"

using namespace std;

int main() {
	CollegeCourse course;
	string department;
	int courseNum, seats;

	cout << "Please enter the Department (use _ for spaces): ";
	cin >> department;
	cout << "Please enter the Course Number: ";
	cin >> courseNum;
	cout << "Please enter the number of seats: ";
	cin >> seats;

	course.setDepartmentAndCourse(department, courseNum);
	course.setSeats(seats);

	course.displayCourseData();

	system("pause");
	return 0;
}