// CollegeCourse.cpp

#include "CollegeCourse.h"
#include <string>
#include <iostream>

using namespace std;

void CollegeCourse::setDepartmentAndCourse(string department, int courseNum) {
	CollegeCourse::department = department;
	CollegeCourse::courseNum = courseNum;
}

void CollegeCourse::setSeats(int seats) {
	CollegeCourse::seats = seats;
}

void CollegeCourse::displayCourseData() {
	cout << "-------------" << endl;
	cout << "Department: " << department << endl;
	cout << "Course Number: " << courseNum << endl;
	cout << "Seats: " << seats << endl;
	cout << "-------------" << endl;
}