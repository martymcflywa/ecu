// Letter.cpp

#include <iostream>
#include <string>
#include "Letter.h"

using namespace std;

void Letter::setRecipient(string title, string recipient) {
	Letter::title = title;
	Letter::recipient = recipient;
}

void Letter::displayGreeting() {
	cout << endl << "Dear " << title << " " << recipient << endl;
	count++;
}

void Letter::displayCount() {
	if (Letter::count == 1) {
		cout << "There is " << Letter::count << " letter.";
	}
	else {
		cout << "There are " << Letter::count << " letters.";
	}
}