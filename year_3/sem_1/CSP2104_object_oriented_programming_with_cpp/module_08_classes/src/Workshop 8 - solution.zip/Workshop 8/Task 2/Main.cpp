// Main.cpp
// Task 2

#include <iostream>
#include <string>
#include "Letter.h"

using namespace std;

int Letter::count = 0;

int main() {
	const int QUIT = -1;
	int keepLooping;
	string title, recipient;
	Letter letter;

	do {
		cout << "Please enter the recipient's title: ";
		cin >> title;
		cout << "Please enter the recipient's name: ";
		cin >> recipient;

		letter.setRecipient(title, recipient);

		cout << endl << endl;
		letter.displayGreeting();
		Letter::displayCount();
		cout << endl << "Kind regards," << endl << "Lecturer" << endl;

		cout << "Another letter? (" << QUIT << " to quit): ";
		cin >> keepLooping;
	} while (keepLooping != QUIT);

	system("pause");
	return 0;
}