// Letter.h

#ifndef LETTER_H
#define LETTER_H

#include <string>

using namespace std;

class Letter {
private:
	string title;
	string recipient;
	static int count;
public:
	void setRecipient(string, string);
	void displayGreeting();
	static void displayCount();
};

#endif