// simple HR system
// read and process personell files in the form:
// employeeID
// employeeName
// position [either manager or worker]
// payRatePerHour

// CSP2104 - Edith Cowan University 2017, Martin Masek.

#include <iostream>
#include <fstream>
#include <string>
#include <vector>

#include "HRSystem.h"

using namespace std;


void main()
{
	// create a HR system
	HRSystem company1("employees.txt");
	// run the HR system
	company1.run();
}


