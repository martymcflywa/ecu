#ifndef CALC_H
#define CALC_H

using namespace std;

class Calc {
public:
	int multiply(int, int);
	int add(int, int);
};

#endif