#include "Calc.h"

using namespace std;

int Calc::multiply(int x, int y) {
	return (x * y);
}

int Calc::add(int x, int y) {
	return (x - y);
}