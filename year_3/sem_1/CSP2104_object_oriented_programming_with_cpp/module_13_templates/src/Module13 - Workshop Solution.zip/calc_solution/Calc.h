#ifndef CALC_H
#define CALC_H

using namespace std;

template <class T>
class Calc {
public:
	T multiply(T, T);
	T add(T, T);
};

template <class T>
T Calc<T>::multiply(T x, T y) {
	return (x * y);
}

template <class T>
T Calc<T>::add(T x, T y) {
	return (x - y);
}

#endif