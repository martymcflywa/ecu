#include <iostream>
#include <string>
#include "SalesOffice.h"

using namespace std;

int main() {
	SalesOffice north("North", 2454.88);
	SalesOffice south("South", 2839.92);

	double ratio = north / south;

	cout << north;
	cout << south;
	cout << "The North Office has " << (ratio * 100) << "% of the sales of South Office" << endl;

	system("pause");
	return 0;
}