#include <iostream>
#include <string>
#include "SalesOffice.h"

using namespace std;

SalesOffice::SalesOffice(string officeName, double sales) {
	this->officeName = officeName;
	this->sales = sales;
}

double SalesOffice::operator/(SalesOffice office) {
	return (this->sales / office.sales);
}

ostream& operator<<(ostream& out, const SalesOffice &anOffice) {
	out << "The " << anOffice.officeName << " Office sold $" << anOffice.sales << endl;
	return out;
}