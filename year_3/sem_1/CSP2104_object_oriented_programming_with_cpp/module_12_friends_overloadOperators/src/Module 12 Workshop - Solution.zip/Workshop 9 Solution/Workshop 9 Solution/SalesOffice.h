#ifndef SALESOFFICE_H
#define SALESOFFICE_H

using namespace std;

class SalesOffice {
	friend ostream& operator<<(ostream&, const SalesOffice&);
private:
	string officeName;
	double sales;
public:
	SalesOffice(string, double);
	double operator/(SalesOffice);
};

#endif