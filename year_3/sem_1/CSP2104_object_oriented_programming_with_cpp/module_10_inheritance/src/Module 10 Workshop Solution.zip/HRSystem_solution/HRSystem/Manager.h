#pragma once
#include "Employee.h";

using namespace std;

class Manager : public Employee
{
public:
	Manager(int id, string name, string position, float payRatePerHour): Employee(id, name, position, payRatePerHour)
	{}
	bool isManager()
	{
		return true;
	}
};
