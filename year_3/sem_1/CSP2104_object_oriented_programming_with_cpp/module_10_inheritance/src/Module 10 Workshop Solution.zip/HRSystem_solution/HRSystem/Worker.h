#pragma once

#include "Employee.h";

using namespace std;

class Worker : public Employee
{
public:
	Worker(int id, string name, string position, float payRatePerHour) : Employee(id, name, position, payRatePerHour)
	{}
	bool isWorker()
	{
		return true;
	}
};
