#pragma once
#include <iostream>
#include <fstream>
#include <string>
#include <vector>
#include "Employee.h"
#include "Worker.h"
#include "Manager.h"
using namespace std;

class HRSystem
{
private:
	vector<Employee*> employees;
public:
	void printAllEmployees()
	{
		cout << "\nList of all employees: \n";
		for (Employee *employee : employees)
		{
			cout << employee->getName() << endl;
		}
	}
	void printManagers()
	{
		cout << "\nList of all managers: \n";
		for (Employee *employee : employees)
		{
			if (employee->isManager())
			{
				cout << employee->getName() << endl;
			}
		}
	}
	void printWorkers()
	{
		cout << "\nList of all workers: \n";
		for (Employee *employee : employees)
		{
			if (employee->isWorker())
			{
				cout << employee->getName() << endl;
			}
		}
	}

	// constructor to load employee records and populate data
	HRSystem(string fileName)
	{
		ifstream myfile(fileName);
		// open the file
		if (myfile.is_open())
		{
			// variables to read data into
			string buffer; // to hold the currently read line from the file
			int currentID = -1;
			string currentName = "none";
			string currentPosition = "none";
			float currentPayRatePerHour = 0;

			// read the records
			while (!myfile.eof())
			{
				// first line holds the ID
				getline(myfile, buffer);
				currentID = stoi(buffer); // using string to int conversion
										  // second line holds the name
				getline(myfile, buffer);
				currentName = buffer;
				// third line holds the position
				getline(myfile, buffer);
				currentPosition = buffer;
				// fourth line holds the pay rate
				getline(myfile, buffer);
				currentPayRatePerHour = stof(buffer); //using string to double conversion

				if (currentPosition == "worker") // is it a worker?
				{
					employees.push_back(new Worker(currentID, currentName, currentPosition, currentPayRatePerHour));
				}
				else // no, then assume its a manager! :)
				{
					employees.push_back(new Manager(currentID, currentName, currentPosition, currentPayRatePerHour));
				}

			}
			myfile.close();
			// now print all the records for verification
			printAllEmployees();
			printManagers();
			printWorkers();
		}
		else cout << "Unable to open file";

	}
	
	void queryPayrate()
	{
		string queryEmployeeName;
		// ask for a name and print the payrate
		cout << "\n\n\n\n\n";
		cout << "---- P A Y R A T E   Q U E R Y ----\n\n";
		cout << "Enter the employee name and press enter:";
		cin >> queryEmployeeName;
		for (Employee *employee : employees)
		{
			if (employee->getName().find(queryEmployeeName) != string::npos)
			{
				// found a matching employee name
				cout << "Match found:\n";
				cout << employee->getName() << " gets $" << employee->getPayRate() << "\n\n";
			}
		}
		
	}
	
	// run the menu of the HR system
	void run()
	{
		bool exit = 0;
		char choice;
		while (!exit)
		{
			// print the menu and ask the use to enter an option
			cout << "\n\n\n\n\n";
			cout << "---- W E L C O M E  T O   H R ----\n\n";
			cout << " 1) Query payrate\n";
			cout << " 2) Exit\n";
			cout << "Enter your choice and press enter:";
			cin >> choice;
			switch (choice)
			{
			case '1':
				queryPayrate();
				break;
			case '2':
				exit = 1;
				break;
			default:
				cout << "\nInvalid option, try again\n";
			}
		}
	}
};