#ifndef LIGER_H
#define LIGER_H

#include <iostream>
#include <string>
#include "Lion.h"
#include "Tiger.h"

using namespace std;

class Liger : public Lion, public Tiger {
public:
	Liger(int, bool, string, string, bool);
	// Overloaded operator to just output the Liger
	void printDecription();
};

#endif