#ifndef TIGER_H
#define TIGER_H

#include <iostream>
#include <string>
#include "Mammal.h"

using namespace std;

class Tiger : virtual public Mammal {
protected:
	// One of these constants should be printed
	// If the fur is white, choose GREY_STRIPE
	const string NORMAL_STRIPE = "brown stripes.";
	const string GREY_STRIPE = "grey stripes.";
public:
	Tiger();
	// Constructor with the base class included
	// The final bool is for 'isMale'
	Tiger(int, bool, string, string, bool);
	// Overlaoded operator to just output the Tiger
	void printDecription();
};

#endif