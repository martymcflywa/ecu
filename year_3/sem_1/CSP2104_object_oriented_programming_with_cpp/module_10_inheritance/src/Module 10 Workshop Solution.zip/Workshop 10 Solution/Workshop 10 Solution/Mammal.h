#ifndef MAMMAL_H
#define MAMMAL_H

#include <iostream>
#include <string>

using namespace std;

class Mammal {
protected:
	int numberOfLegs;
	bool hasATail;
	bool isMale;
	string furColour;
	string eyeColour;
public:
	Mammal();
	// Constructor
	Mammal(int, bool, string, string);
	// Overloaded operator to just output the Mammal
	void printDecription();
};

#endif