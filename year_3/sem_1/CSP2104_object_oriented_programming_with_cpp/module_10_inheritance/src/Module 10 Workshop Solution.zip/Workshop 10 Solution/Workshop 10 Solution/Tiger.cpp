#include <iostream>
#include <string>
#include "Tiger.h"

using namespace std;

Tiger::Tiger() {}

Tiger::Tiger(int legs, bool tail, string fur, string eyes, bool male) 
	: Mammal(legs, tail, fur, eyes) {
	isMale = male;
}

void Tiger::printDecription() {
	cout << "This Tiger is a mammal that walks on " << numberOfLegs <<
		" legs and has " << (hasATail ? "a tail." : "no tail.") << endl;
	cout << "It is " << (isMale ? "a male" : "a female");
	cout << " and has " << furColour << " fur, which means it has ";

	if (furColour == "white" || furColour == "White")
		cout << GREY_STRIPE << endl << endl;
	else
		cout << NORMAL_STRIPE << endl << endl;
}