#include <iostream>
#include <string>
#include "Mammal.h"

using namespace std;

Mammal::Mammal() {}

Mammal::Mammal(int legs, bool tail, string fur, string eye) {
	numberOfLegs = legs;
	hasATail = tail;
	furColour = fur;
	eyeColour = eye;
}

void Mammal::printDecription() {
	cout << "This animal walks on " << numberOfLegs << " legs and has "
		<< (hasATail ? "a tail." : "no tail.") << endl;
	cout << "It has " << furColour << " fur and " <<
		eyeColour << " eyes." << endl << endl;
}