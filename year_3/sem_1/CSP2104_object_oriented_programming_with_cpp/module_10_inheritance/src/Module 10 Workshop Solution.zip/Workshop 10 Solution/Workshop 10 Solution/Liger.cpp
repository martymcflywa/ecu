#include <iostream>
#include <string>
#include "Liger.h"

using namespace std;

Liger::Liger(int legs, bool tail, string fur, string eyes, bool male)
	: Mammal(legs, tail, fur, eyes) {
	isMale = male;

	isMale ? hasAMane = true : hasAMane = false;
}

void Liger::printDecription() {
	cout << "This Liger is a mammal that walks on " << numberOfLegs <<
		" legs and has a tail." << endl;
	cout << "It is a " << (isMale ? "male with a mane of " : "female with ") <<
		furColour << " fur, which means it has ";

	if (furColour == "white" || furColour == "White")
		cout << GREY_STRIPE << endl << endl;
	else
		cout << NORMAL_STRIPE << endl << endl;
}