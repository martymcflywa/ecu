#include <iostream>
#include <string>
#include "Mammal.h"
#include "Lion.h"
#include "Tiger.h"
#include "Liger.h"

using namespace std;

int main() {

	// Part One
	Mammal animalOne(4, true, "brown", "brown");
	animalOne.printDecription();
	Mammal animalTwo(2, false, "black", "blue");
	animalTwo.printDecription();

	// Part Two
	Lion lionOne(4, true, "golden", "brown", true);
	lionOne.printDecription();
	Lion lionTwo(4, true, "white", "blue", false);
	lionTwo.printDecription();

	// Part Three
	Tiger tigerOne(4, true, "orange", "brown", false);
	tigerOne.printDecription();
	Tiger tigerTwo(4, true, "white", "blue", true);
	tigerTwo.printDecription();

	// Part Four
	Liger ligerOne(4, true, "white", "blue", true);
	ligerOne.printDecription();
	Liger ligerTwo(4, true, "tan", "brown", false);
	ligerTwo.printDecription();

	system("pause");
	return 0;
}