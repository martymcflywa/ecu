#include <iostream>
#include <string>
#include "Lion.h"

using namespace std;

Lion::Lion() {}

Lion::Lion(int legs, bool tail, string fur, string eyes, bool male) 
	: Mammal(legs, tail, fur, eyes) {
	isMale = male;

	male ? hasAMane = true : hasAMane = false;
}

void Lion::printDecription() {
	cout << "This Lion is a mammal that walks on " << numberOfLegs <<
		" legs and has " << (hasATail ? "a tail." : "no tail.") << endl;
	cout << "It is " << (isMale ? "a male with a mane of " : "a female with ")
		<< furColour << " fur and " << eyeColour << " eyes." << endl << endl;
}