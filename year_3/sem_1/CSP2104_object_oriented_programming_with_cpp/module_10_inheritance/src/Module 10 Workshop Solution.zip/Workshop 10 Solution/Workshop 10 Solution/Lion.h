#ifndef LION_H
#define LION_H

#include <iostream>
#include <string>
#include "Mammal.h"

using namespace std;

class Lion : virtual public Mammal {
protected:
	// Should be set if the gender is Male
	bool hasAMane;
public:
	Lion();
	// Constructor with the base class included
	// The final bool is for 'isMale'
	Lion(int, bool, string, string, bool);
	// Overloaded operator to just output the Lion
	void printDecription();
};

#endif LION_H