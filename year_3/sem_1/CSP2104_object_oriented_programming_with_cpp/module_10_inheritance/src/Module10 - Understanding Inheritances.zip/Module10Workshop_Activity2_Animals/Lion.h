#ifndef LION_H
#define LION_H

#include <iostream>
#include <string>
#include "Mammal.h"

using namespace std;

class Lion : public Mammal {
protected:
	// Should be set if the gender is Male
	// This should not be modified by the constructor
	bool hasAMane;
public:
	// Constructor with the base class included
	// The final bool is for 'isMale'
	Lion(int, bool, string, string, bool);
	// Overloaded function to just output the Lion
	void printDecription();
};

#endif LION_H