#ifndef MAMMAL_H
#define MAMMAL_H

#include <iostream>
#include <string>

using namespace std;

class Mammal {
protected:
	int numberOfLegs;
	bool hasATail;
	// Not in constructor, can modify to include if you wish
	bool isMale;
	string furColour;
	string eyeColour;
public:
	// Constructor
	Mammal(int, bool, string, string);
	// Base function to just output the Mammal
	void printDecription();
};

#endif