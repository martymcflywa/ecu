#pragma once
#include <iostream>
#include <string>
#include <vector>
using namespace std;

class Employee
{
private:
	int employeeID;
	string name;
	string position;
	float payRatePerHour;
public:
	// constructor.
	Employee(int id, string name, string position, float payRatePerHour)
	{
		employeeID = id;
		Employee::name = name;
		Employee::position = position;
		Employee::payRatePerHour = payRatePerHour;
	}

	// getter methods for the class
	string getName()
	{
		return name;
	}

	float getPayRate()
	{
		return payRatePerHour;
	}

	bool isManager()
	{
		if (position == "manager")
		{
			return true;
		}
		return false;
	}

	bool isWorker()
	{
		if (position == "worker")
		{
			return true;
		}
		return false;
	}
};