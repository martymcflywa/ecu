// Source.cpp

#include <iostream>
#include <string>
#include "Pizza.h"

using namespace std;

void taskOne();
void taskTwo();

int main() {

	taskOne();
	//taskTwo();

	system("pause");
	return 0;
}

void taskOne() {
	Pizza stdPizza("cheese", 12, 8.99);
	char input;

	cout << "The standard pizza is: ";
	stdPizza.displayValues();
	cout << "\nLet me take your order" << endl;
	cout << "Do you want the standard pizza - y or n? ";
	cin >> input;

	if (input == 'y' || input == 'Y') {
		cout << "Your order is a ";
		stdPizza.displayValues();
	}
	else
		cout << "No pizza for you!";

	cout << endl;
}

void taskTwo() {
	Pizza stdPizza;
	Pizza special("pineapple");
	Pizza deluxeSpecial("sausage", 16);
	Pizza veryDeluxeSpecial("lobster", 20, 17.99);

	cout << "The standard pizza is: ";
	stdPizza.displayValues();
	cout << "\nToday's special is: ";
	special.displayValues();
	cout << "\nThe deluxe special is: ";
	deluxeSpecial.displayValues();
	cout << "\nAnd the very deluxe special is: ";
	veryDeluxeSpecial.displayValues();
	cout << endl;
}