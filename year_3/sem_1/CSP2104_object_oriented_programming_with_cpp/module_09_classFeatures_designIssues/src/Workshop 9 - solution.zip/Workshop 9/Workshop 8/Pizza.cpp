// Pizza.cpp

#include <iostream>
#include <string>
#include "Pizza.h"

Pizza::Pizza(const string top, const int size, const double price) {
	topping = top;
	diameter = size;
	this->price = price;
}

void Pizza::displayValues() {
	cout << "a " << diameter << " inch " << topping << " pizza. Price $" << price;
}

// Task 2

Pizza::Pizza() {
	topping = "cheese";
	diameter = 12;
	price = 8.99;
}

Pizza::Pizza(const string top) {
	topping = top;
	diameter = 12;
	price = 8.99;
}

Pizza::Pizza(const string top, const int size) {
	topping = top;
	diameter = size;
	price = 8.99;
}