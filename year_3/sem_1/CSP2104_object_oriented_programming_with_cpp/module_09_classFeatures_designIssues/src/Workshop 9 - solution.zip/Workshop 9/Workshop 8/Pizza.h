// Pizza.h

#ifndef PIZZA_H
#define PIZZA_H

#include <iostream>

using namespace std;

class Pizza {
private:
	string topping;
	int diameter;
	double price;
public:
	Pizza(const string, const int, const double);
	void displayValues();
	// Task 2 - Overloaded constructors
	// This could also be done with a constructor that has default values
	// ie, Pizza(const string = "cheese", const int = 12, const double = 8.99);
	Pizza();
	Pizza(const string);
	Pizza(const string, const int);
};

#endif