// Name.h

#ifndef NAME_H
#define NAME_H

#include <string>

using namespace std;

class Name {
private:
	string first;
	string middle;
	string last;
public:
	Name(string, string, string);
	void displayFullName();
};

#endif