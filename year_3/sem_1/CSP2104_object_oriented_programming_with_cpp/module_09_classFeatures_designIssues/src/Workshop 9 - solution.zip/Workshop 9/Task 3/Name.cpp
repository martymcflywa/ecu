// Name.cpp

#include <iostream>
#include <string>
#include "Name.h"

using namespace std;

Name::Name(string first, string middle, string last) {
	this->first = first;
	this->middle = middle;
	this->last = last;
}

void Name::displayFullName() {
	cout << first << " " << middle << " " << last << endl;
}