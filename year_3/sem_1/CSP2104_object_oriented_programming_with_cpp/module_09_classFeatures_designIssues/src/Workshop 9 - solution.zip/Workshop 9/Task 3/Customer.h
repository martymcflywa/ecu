// Customer.h

#ifndef CUSTOMER_H
#define CUSTOMER_H

#include <string>

#include "CreditData.h"
#include "Name.h"

using namespace std;

class Customer {
private:
	Name name;
	CreditData credit;
	string phoneNumber;
public:
	Customer(string, string, string, double, double, string);
	void showCustomer();
};

#endif