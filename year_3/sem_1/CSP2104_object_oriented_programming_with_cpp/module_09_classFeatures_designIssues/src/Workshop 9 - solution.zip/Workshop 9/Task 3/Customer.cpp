// Customer.cpp

#include <iostream>
#include <string>
#include "Customer.h"

using namespace std;

Customer::Customer(string firstName, string middleName, string lastName,
	double bal, double max, string phone) : 
	name(firstName, middleName, lastName),
	credit(bal, max) {

	phoneNumber = phone;
}

void Customer::showCustomer() {
	cout << "Customer data:" << endl;
	name.displayFullName();
	cout << phoneNumber << endl;
	credit.displayCreditData();
}