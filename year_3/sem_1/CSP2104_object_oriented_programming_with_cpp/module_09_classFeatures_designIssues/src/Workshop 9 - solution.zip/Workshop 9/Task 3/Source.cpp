// Source.cpp

#include <iostream>
#include <string>
#include "Customer.h"

using namespace std;

int main() {
	string firstName, middleName, lastName, phone;
	double currentBalance , maxBalance;

	cout << "Please enter first name for customer: ";
	cin >> firstName;
	cout << "Please enter middle name: ";
	cin >> middleName;
	cout << "Please enter last name: ";
	cin >> lastName;
	cout << "Enter current balance: $";
	cin >> currentBalance;
	cout << "Enter credit limit: $";
	cin >> maxBalance;
	cout << "Enter phone number: ";
	cin >> phone;
	cout << endl;

	Customer customer(firstName, middleName, lastName, currentBalance, maxBalance, phone);
	customer.showCustomer();

	system("pause");
	return 0;
}