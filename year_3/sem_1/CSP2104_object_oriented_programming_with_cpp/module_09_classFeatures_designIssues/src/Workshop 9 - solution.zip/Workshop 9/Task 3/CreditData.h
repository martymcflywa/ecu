// CreditData.h

#ifndef CREDITDATA_H
#define CREDITDATA_H

using namespace std;

class CreditData {
private:
	double currentBalance;
	double maxBalance;
public:
	CreditData(double, double = 0);
	void displayCreditData();
};

#endif