<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.0 Transitional//EN">
<HTML>
 <BODY>

	<?php

		//Go through $_POST array and put non-empty fields into $products array
		foreach ($_POST as $key => $value)
		{
			if ($value != '')
			{
				$products[$key] = $value;
			}
		}

		//Display names and contents of $products array
		$count = 0;
		foreach ($products as $key => $value)
		{
			
		echo $products['ProductID_'.$count] . ' ' . $products['Price1_'.$count] . ' ' . $products['Price2_'.$count] . ' ' . $products['Price3_'.$count] . '<p>';

		$count = $count + 1;



		}

	?>

 </BODY>
</HTML>
