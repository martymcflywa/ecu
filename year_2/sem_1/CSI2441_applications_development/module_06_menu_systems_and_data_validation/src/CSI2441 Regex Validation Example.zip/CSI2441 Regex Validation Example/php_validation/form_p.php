<head>
<title>Process Order Form PHP</title>

</head>

<body>


<?php

//################################################################################
//
//			This is the php version to process the form.
//
//			Coded by:
//
//					Stuart Woods 
//					ECU BSc(Web Technology) W.I.L. Student
//					Validation Code Example
//
//		
//################################################################################



//-----------------------GET THE FORM DATA --------------------------

// Read the header information into variable

$clientFirstName = trim($_POST['Client_Firstname']);
$clientSurname = trim($_POST['Client_Surname']);
$clientID = trim($_POST['ClientID']);

// Get the data from the first line of the form
$orderLine1Code = trim($_POST['ProductCode_1']);
$orderLine1Cost = trim($_POST['ProductCost_1']);
$orderLine1Ordered = trim($_POST['NoOrdered_1']);

//----------------VALIDATE DATA COLLECTED FROM FORM---------------------

	
// // VALIDATE CLIENT'S FIRST NAME

// Set this variable to 1, meaning that the form is valid.
$FormValid = 1;

// Initialise error message string
$ErrorMessages = "";

// Must not be blank
// Only letters and ' and -
// Using preg_match "perform regular expression match"
// Google "php regex cheat sheet" for definitions or regex parts

// ie. If the first name contains invalid characters or contains nothing...
if (!preg_match("/^[a-zA-Z'-]*$/",$clientFirstName) || $clientFirstName=="") 
{
	// Add an error message to this string...
	$ErrorMessages = $ErrorMessages."Client first name is not valid (Must consist of letters and  '  or - only).<br>";
	
	// Set this to 0 meaning that the form is not valid.
	$FormValid = 0;
}



// VALIDATE CLIENT'S SURNAME

// Must not be blank
// Only letters and ' and -
// Using preg_match "perform regular expression match"

// ie. If the first name contains invalid characters or contains nothing...
if (!preg_match("/^[a-zA-Z'-]*$/",$clientSurname) || $clientSurname=="") 
{
	// Add an error message to this string...
	$ErrorMessages = $ErrorMessages."Client surname is not valid (Must consist of letters and  '  or - only).<br>";
	// Set this to 0 meaning that the form is not valid.
	$FormValid = 0;
}



// VALIDATE CLIENT'S ID

// Must be digits/numbers only, 6 to 8 digits long

// ie. ^ = begin at start or string, \d = digits only, {6,8} = 6 to 8 digits only, $ = end of string
if(!preg_match("/^\d{6,8}$/",$clientID) || $clientID=="")
{
	$ErrorMessages = $ErrorMessages."Client ID is not valid (Must be 6 to 8 digit number).<br>";
	$FormValid = 0;
}



// VALIDATE THE FIRST LINE OF THE FORM ONLY: in all of these code examples the Line number (ie Line1) has been hard-coded. 
//In reality you would replace this with a counter iiterating through the form using a counter (like that shown in the week 2 code examples)

// Make sure that there are no empty fields in line 1 on the form
if (($orderLine1Code == "") || ($orderLine1Cost == "") || ($orderLine1Ordered == ""))
{
	$ErrorMessages = $ErrorMessages."Line1 has one or more empty fields";
	$FormValid = 0;
}

// Validate the product code on line 1 of the form
// Must be four letters followed by three digits - XXXX999
if	((!(preg_match('/[A-Za-z]{4}[0-9]{3}+$/',$orderLine1Code))) && (!($orderLine1Code == "")))
{
	$ErrorMessages = $ErrorMessages."Order line 1 has invalid product code entered. (Must be 4 letters followed by 3 numbers)";
	$FormValid = 0;
}

// Validate Product Cost for line 1 of the form - no $ and 000.00 only
if ((!(is_numeric($orderLine1Cost))) && (!($orderLine1Cost == "")))
{
	$ErrorMessages = $ErrorMessages."Order line 1 has invalid price entered.(do not use $ sign, 000.00 only)";
	$FormValid = 0;
}

// Validate Number Ordered for line 1 of the form- Integer > 0
if ((!(preg_match('/^[\d]*$/',$orderLine1Ordered))) && ($orderLine1Ordered != ""))
	{
		$ErrorMessages = $ErrorMessages."Order line 1 has invalid number of products.(whole numbers > 0 only)";
		$FormValid = 0;
	}




// IF FORM INVALID DISPLAY ERROR MESSAGES OR DO STUFF

if ($FormValid == 0)
{
	// Display the error messages and prompt to go back and fix them.
	echo $ErrorMessages.'<br/>';
	echo 'Please go back and fix these errors';
	echo '<br/><input type="button" onclick="history.back();" value="Back" />'; 
}
else
{
	// Do stuff here
	echo "The header and first line of your form is valid.";
}

?>
