import au.edu.ecu.is.evolution.*;

import java.util.Random;

/**
 * A class describing a function approximation problem
 * 
 * @author (phi) 
 * @version (2003/2)
 */
public class FunctionProblem
{   
    // calculate the value of the target function
    // with the current values of A and B
    public static double evaluate()
    {
        double a = ((Double)A.evaluate(null)).doubleValue();
        double b = ((Double)B.evaluate(null)).doubleValue();
        
        return target(a, b);
   }
   
   private static double target(double a, double b)
   {
        return Math.sqrt(a*a+b*b); // change this to try other problems
   }
    
    // array of functions to use in expression trees
    public static PrimitiveFunction[] getFunctions()
    {
        return functions;
    }
    
    // return type of the expression trees
    public static Class getReturnType()
    {
        return Double.class;
    }
    
    // variables in the expression tree
    public static VariableTerminal[] getVariables()
    {
        return variables;
    }

    // test cases to evaluate expression trees
    // as approximation of the target function
    public static double[][] getTestCases()
    {
        return testCases;
    }
           
    // the variables
    private static VariableTerminal A = new VariableTerminal("A", new Double(0.0));
    private static VariableTerminal B = new VariableTerminal("B", new Double(0.0));
     
    // the functions
    private static PrimitiveFunction times = new PrimitiveFunction("*", new Class[]{Double.class, Double.class}, Double.class)
        {
            public Object evaluate(Object[] args)
            {
                return new Double(((Double)args[0]).doubleValue()*((Double)args[1]).doubleValue());
            }
        };
    private static PrimitiveFunction divide = new PrimitiveFunction("/", new Class[]{Double.class, Double.class}, Double.class)
        {
            public Object evaluate(Object[] args)
            {
                return new Double(((Double)args[0]).doubleValue()/((Double)args[1]).doubleValue());
            }
        };
    private static PrimitiveFunction plus = new PrimitiveFunction("+", new Class[]{Double.class, Double.class}, Double.class)
        {
            public Object evaluate(Object[] args)
            {
                return new Double(((Double)args[0]).doubleValue()+((Double)args[1]).doubleValue());
            }
        };
    private static PrimitiveFunction subtract = new PrimitiveFunction("-", new Class[]{Double.class, Double.class}, Double.class)
        {
            public Object evaluate(Object[] args)
            {
                return new Double(((Double)args[0]).doubleValue()-((Double)args[1]).doubleValue());
            }
        };
    private static PrimitiveFunction sqrt = new PrimitiveFunction("sqrt", new Class[]{Double.class}, Double.class)
        {
            public Object evaluate(Object[] args)
            {
                return new Double(Math.sqrt(((Double)args[0]).doubleValue()));
            }
        };
        
    // convert errors to fitness values
    public static double errorToFitness(double error)
    {
        return 1.0/(1.0 + FACTOR*error);
    }
    
    // and back again
    public static double fitnessToError(double fitness)
    {
        return (1.0/fitness - 1.0)/FACTOR;
    }

    private static final double FACTOR = 0.1;
    
    private static PrimitiveFunction[] functions = {A, B, times, divide, plus, subtract, sqrt};
    private static VariableTerminal[] variables = {A, B};
    
    private static double[][] testCases;
    
    static
    {
        testCases = new double[][]
            {
                {3, 5, target(3, 5)},
                {8, 14, target(8, 14)},
                {18, 2, target(18, 2)},
                {32, 11, target(32, 11)},
                {4, 3, target(4, 3)},
                {12, 10, target(12, 10)},
                {21, 6, target(21, 6)},
                {7, 4, target(7, 4)},
                {16, 24, target(16, 24)},
                {2, 9, target(2, 9)}
            };
    }
}
