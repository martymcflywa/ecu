import au.edu.ecu.is.evolution.*;

import java.util.Random;

/**
 * A GP example from Negnevistky
 * 
 * @author (phi) 
 * @version (2003/2)
 */
public class EvolveFunction
{
    public static void main(String[] args)
    {
        EvolveFunction evolver = new EvolveFunction();
        
        try
        {
            evolver.go();
        }
        catch(Exception e)
        {
            e.printStackTrace(System.out);
        }
    }
    
    public void go() throws EvolutionException
    {
        Random random = new Random();
                       
        GeneticProgrammingAlgorithm gp = new GeneticProgrammingAlgorithm
            (
                random,
                MAXSIZE,
                FunctionProblem.getFunctions(),
                FunctionProblem.getReturnType(),
                POP,
                MUTATIONPROB,
                CROSSOVERPROB,
                new FunctionEvaluator(),
                new GenerationsTerminator(GEN),
                new StochasticUniformSelector(random)
            );
            
        gp.test();

        gp.display();
    }
 
    private static final int POP = 100;
    private static final int GEN = 5000;
    private static final int MAXSIZE = 12;//20;
    private static final double MUTATIONPROB = 0.8;
    private static final double CROSSOVERPROB = 0.1;
}
