import au.edu.ecu.is.evolution.*;

/**
 * A class to evaluate approximations to an expression.
 * 
 * @author (phi) 
 * @version (2003/2)
 */
public class FunctionEvaluator extends Evaluator
{
    public double evaluate(Evolvable evolvable)
    {
        EvolvableExpressionTree tree = (EvolvableExpressionTree)evolvable;
        double errors;
        
        try
        {
            errors = getErrors(tree);
        }
        catch(Exception e)
        {
            e.printStackTrace(System.out);
            errors = 1E6;
        }
        
        return FunctionProblem.errorToFitness(errors);
    }
    
    private double getErrors(EvolvableExpressionTree tree) throws EvolutionException
    {
        VariableTerminal[] variables = FunctionProblem.getVariables();
        double[][] testCases = FunctionProblem.getTestCases();
        
        double errors = 0.0;
        
        for(int i = 0; i < testCases.length; i++)
        {
            variables[0].setValue(new Double(testCases[i][0]));
            variables[1].setValue(new Double(testCases[i][1]));
            
            Double result = (Double)tree.evaluate();
            double correct = FunctionProblem.evaluate();
            Double correctD = new Double(correct);
            if(result.isNaN() || result.isInfinite())
            {
                errors += 1E6;
            }
            else
            {
                errors += Math.abs(result.doubleValue() - correct);
            }
        }

        return errors + 0.01*tree.getSize();
    }
    
    private FunctionProblem functionProblem;
}
