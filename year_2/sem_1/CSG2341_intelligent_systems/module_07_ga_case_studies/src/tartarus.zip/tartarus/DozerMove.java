/*
 * DozerMove.java
 *
 * Created on 4 August 2006, 22:46
 *
 * To change this template, choose Tools | Template Manager
 * and open the template in the editor.
 */

/**
 *
 * @author phingsto
 */
public enum DozerMove
{
    FORWARD, LEFT, RIGHT
}
