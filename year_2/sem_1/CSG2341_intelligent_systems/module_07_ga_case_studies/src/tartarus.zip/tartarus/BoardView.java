/*
 * BoardView.java
 *
 * Created on 27 July 2006, 20:07
 *
 */

/**
 *
 * @author phingsto
 */
public enum BoardView
{
    ALL, LOCAL, EGO
}
