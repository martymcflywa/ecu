/*
 * CellState.java
 *
 * Created on 27 July 2006, 09:36
 *
 */

/**
 *
 * @author phingsto
 */
public enum CellState
{
	EMPTY, BOX, WALL
}
