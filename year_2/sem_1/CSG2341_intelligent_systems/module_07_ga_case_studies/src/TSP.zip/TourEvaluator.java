import Evolution.*;

/**
 * A class to evaluate tours as solutions to a TSP problem
 * 
 * @author (your name) 
 * @version (a version number or a date)
 */
public class TourEvaluator extends Evaluator
{
    /**
     * Constructor for a TSP tour evaluator
     * 
     * @param tsp the problem instance
     * 
     */
    public TourEvaluator(TSP tsp)
    {
        this.tsp = tsp;
    }
        
    /**
     * Evaluate one tour
     * 
     * @param tour the tour to evaluate
     * 
     */
    public double evaluate(Evolvable evolvable)
    {
        EvolvableTour tour = (EvolvableTour)evolvable;
        // Fitness has to be inverted as the GA will maximise, and
        // we want a minimum length tour
        // Fitness values need to be > 0 though, so be careful.
        // This is safe because our cities are all inside a unit square.
        return 2.0*tsp.getSize() - tsp.getLength(tour.getTour());
    }
    
    TSP tsp;    // the TSP instance
}
