import Evolution.*;

import java.util.*;
import java.awt.*;

/**
 * A class to represent possible tours for a TSP problem
 * 
 * @author (phi) 
 * @version (2003/2)
 */
public class EvolvableTour extends PermutationEvolvable
{
    /**
     * Constructor for an evolvable tour
     * 
     * @param random a random number generator
     * @param tsp a TSP problem instance
     */
    public EvolvableTour(Random random, TSP tsp)
    {
        super(random, tsp.getSize());
        
        this.tsp = tsp;
    }
    
    /**
     * The genotype is enough - nothing extra needed
     * 
     */
    public void develop()
    {
    }
    
    /**
     * A method to draw a graphical representation of the tour.
     * Called to show th ebest solution when the GA is displayed.
     * 
     * @param g the graphics context
     * @param viewport a rectangular area to draw into
     */
    public void draw(Graphics g, Rectangle viewport)
    {
        tsp.draw(g, viewport);
        tsp.drawTour(g, chromosome, viewport);
    }
    
    /**
     * Get the tour 
     *
     * @return as an array of city numbers in the order visited
     */
    public int[] getTour()
    {
        return chromosome;
    }
                
    private TSP tsp;    // the TSP problem instance
}
