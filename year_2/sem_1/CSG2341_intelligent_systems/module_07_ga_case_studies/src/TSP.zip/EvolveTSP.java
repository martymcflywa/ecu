import Evolution.*;

import java.util.*;

/**
 * A driver class for a genetic algorithm to solve TSP instances.
 * 
 * @author (phi) 
 * @version (2003/2)
 */
public class EvolveTSP
{
    public static void main(String[] args)
    {
        EvolveTSP evolver = new EvolveTSP();
        
        try
        {
            evolver.go();
        }
        catch(Exception e)
        {
            e.printStackTrace(System.out);
        }
    }
    
    public void go() throws EvolutionException
    {
        Random random = new Random();
        TSP tsp = new TSP(random, SIZE);
               
        Object[] constructorParams = {random, tsp};
        
        GeneticAlgorithm ga = new GeneticAlgorithm
            (
                EvolvableTour.class,
                constructorParams,
                POP,
                random,
                MUTATIONPROB,
                CROSSOVERPROB,
                new TourEvaluator(tsp),
                new GenerationsTerminator(GENERATIONS),
                new StochasticUniformSelector(random),
                true
            );
        
        //ga.test();
        ga.display();
    }

    private static final int SIZE = 30;    
    private static final int GENERATIONS = 10000;
    private static final int POP = 100;
    private static final double MUTATIONPROB = 0.5;
    private static final double CROSSOVERPROB = 0.6;
}
