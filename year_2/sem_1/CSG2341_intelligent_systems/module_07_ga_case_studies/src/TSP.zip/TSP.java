import java.awt.*;
import java.util.*;

/**
 * Class to respesent a TSP problem instance
 * 
 * @author (phi) 
 * @version (2003/2)
 */
public class TSP
{   
    /**
     * Constructor creates a random TSP problem instance
     * Cities are placed randomly within a unit square.
     * 
     * @param random a random number generator
     * @param size the number of cities
     * 
     */
    public TSP(Random random, int size)
    {
        this.size = size;
        coords = new double[size][];
        for(int i = 0; i < size; i++)
        {
            coords[i] = new double[2];
        }
        for(int i = 0; i < size; i++)
        {
            coords[i][0] = random.nextDouble();
            coords[i][1] = random.nextDouble();
        }
    }

    /**
     * Get the number of cities
     * 
     * @return the number
     * 
     */
    public int getSize()
    {
        return size;
    }

    /**
     * Calculate the distance between two cities
     * 
     * @param from the index of the starting city
     * @param to the index of the destination city
     * 
     * @ return the distance between them
     */
    private double getDistance(int from, int to)
    {   
        return Math.sqrt((coords[from][0]-coords[to][0])*(coords[from][0]-coords[to][0]) +
                         (coords[from][1]-coords[to][1])*(coords[from][1]-coords[to][1]));
    }

    /**
     * Calculate the length of a tour.
     * 
     * @param tour the tour as an array of city indices
     * 
     * @return the length of the tour
     */
    public double getLength(int[] tour)
    {
        double length = 0.0;
        for(int i = 0; i < tour.length-1; i++)
        {
            length += getDistance(tour[i], tour[i+1]);
        }
        length += getDistance(tour[0], tour[tour.length-1]);
        return length;
    }

    /**
     * Draw a graphical representation of the problem
     * 
     * @param g the graphics context
     * @param a rectangle to draw into
     */
    public void draw(Graphics g, Rectangle viewport)
    {
        g.setColor(Color.lightGray);
        for(int i = 0; i < size; i++)
        {
            int x1 = (int)Math.round(viewport.x + viewport.width*coords[i][0]);
            int y1 = (int)Math.round(viewport.y + viewport.height - viewport.height*coords[i][1]);
            for(int j = 0; j < i; j++)
            {
                int x2 = (int)Math.round(viewport.x + viewport.width*coords[j][0]);;
                int y2 = (int)Math.round(viewport.y + viewport.height - viewport.height*coords[j][1]);
                g.drawLine(x1, y1, x2, y2);
            }
        }

        g.setColor(Color.gray);
        for(int i = 0; i < size; i++)
        {
            int x1 = (int)Math.round(viewport.x + viewport.width*coords[i][0]);
            int y1 = (int)Math.round(viewport.y + viewport.height - viewport.height*coords[i][1]);
            g.fillOval(x1 - 5, y1 - 5, 11, 11);
        }
    }

    /**
     * Draw a particular tour instance.
     * Designed to draw over the top of a representation of the problem.
     * 
     * @param g the graphics context
     * @param tour the tour as an array of city indices
     * @param a rectangle to draw into
     * 
     * @see public void draw(Graphics g, Rectangle viewport)
     * 
     */
    public void drawTour(Graphics g, int[] tour, Rectangle viewport)
    {
        g.setColor(Color.black);
        for(int i = 0; i < tour.length-1; i++)
        {
            int x1 = (int)Math.round(viewport.x + viewport.width*coords[tour[i]][0]);
            int y1 = (int)Math.round(viewport.y + viewport.height - viewport.height*coords[tour[i]][1]);
            int x2 = (int)Math.round(viewport.x + viewport.width*coords[tour[i+1]][0]);
            int y2 = (int)Math.round(viewport.y + viewport.height - viewport.height*coords[tour[i+1]][1]);
            g.drawLine(x1, y1, x2, y2);
        }
        int x1 = (int)Math.round(viewport.x + viewport.width*coords[tour[0]][0]);
        int y1 = (int)Math.round(viewport.y + viewport.height - viewport.height*coords[tour[0]][1]);
        int x2 = (int)Math.round(viewport.x + viewport.width*coords[tour[tour.length-1]][0]);
        int y2 = (int)Math.round(viewport.y + viewport.height - viewport.height*coords[tour[tour.length-1]][1]);
        g.drawLine(x1, y1, x2, y2);
        
        g.setColor(Color.blue);
        g.drawString(""+getLength(tour), viewport.x + 5, viewport.y + 10);
    }   

    private int size;           // the number of cities
    private double[][] coords;  // their coordinates, indexed by city number
}
