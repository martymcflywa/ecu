import Evolution.*;

/**
 * A class to evaluate maintenance schedules.
 * 
 * @author (phi) 
 * @version (2003/2)
 */
public class ScheduleEvaluator extends Evaluator
{ 
    /**
     * Constructor for schedule evaluators
     * 
     * @param problem a problem instance
     * 
     */
    public ScheduleEvaluator(ScheduleProblem problem)
    {
        this.problem = problem;
    }
        
    /**
     * A method to evaluate the fitness of a schedule
     * 
     * @return the fitness value
     * 
     */
    public double evaluate(Evolvable evolvable)
    {
        EvolvableSchedule sched = (EvolvableSchedule)evolvable;
        boolean[][] schedule = sched.getSchedule();
        double fitness = 1E6;
        
        for(int i = 0; i < problem.nIntervals; i++)
        {
            double available = 0.0;
            for(int j = 0; j < problem.nUnits; j++)
            {
                if(!schedule[j][i])
                {
                    available += problem.unitCapacity[j];
                }
            }
            fitness = Math.min(fitness, available - problem.intervalLoads[i]);
            
            if(fitness <= 0) return 0;
        }
        
        return fitness;
    }
    
    private ScheduleProblem problem;
}
