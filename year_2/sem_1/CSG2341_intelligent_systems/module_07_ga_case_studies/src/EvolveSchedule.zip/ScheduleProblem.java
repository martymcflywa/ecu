
/**
 * A class for scheduling problems like the one in the text book.
 * See Negnevitsky section 7.5
 * 
 * @author (phi) 
 * @version (2003/2)
 */
public class ScheduleProblem
{
    private ScheduleProblem()
    {
    }
    
    /**
     * Get a schedule problem instance
     * 
     * @param number must be 0 (for the text book example), or 1 for the harder example
     * 
     * @returns the problem instance
     */
    public static ScheduleProblem getScheduleProblem(int number)
    {
        return problems[number];
    }
       
    private static ScheduleProblem[] problems;

    // static block that creates the two instances
    static
    {
        problems = new ScheduleProblem[2];
        
        // the text book example
        problems[0] = new ScheduleProblem();
        
        problems[0].nUnits = 7;
        problems[0].nIntervals = 4;
        
        // allowed patterns for units that need two intervals for maintenance
        problems[0].intervalPatterns2 = new boolean[][]
            {
                {true, true, false, false},
                {false, true, true, false},
                {false, false, true, true}
            };
        // allowed patterns for units that only need one interval for maintenance
        problems[0].intervalPatterns1 = new boolean[][]
            {
                {true, false, false, false},
                {false, true, false, false},
                {false, false, true, false},
                {false, false, false, true}
            };
        // allowed patterns indexed by unit number
        problems[0].unitTypes = new boolean[][][]
            {
                problems[0].intervalPatterns2,
                problems[0].intervalPatterns2,
                problems[0].intervalPatterns1,
                problems[0].intervalPatterns1,
                problems[0].intervalPatterns1,
                problems[0].intervalPatterns1,
                problems[0].intervalPatterns1
            }; 
        // unit capacities indexed by unit number
        problems[0].unitCapacity = new double[]{20, 15, 35, 40, 15, 15, 10};
        // interval loads indexed by interval
        problems[0].intervalLoads = new double[]{80, 90, 65, 70};
        
        // compute total capacity for this problem
        problems[0].totalCapacity = 0.0;
        // also populate sizes array - number of allowed patterns for each unit 
        problems[0].sizes = new int[problems[0].nUnits];
        for(int unit = 0; unit < problems[0].nUnits; unit++)
        {
            problems[0].totalCapacity += problems[0].unitCapacity[unit];
            problems[0].sizes[unit] = problems[0].unitTypes[unit].length;
        }

        // the harder one
        problems[1] = new ScheduleProblem();
        
        problems[1].nUnits = 15;
        problems[1].nIntervals = 8;
        
        problems[1].intervalPatterns2 = new boolean[][]
            {
                {true, true, false, false, false, false, false, false},
                {false, true, true, false, false, false, false, false},
                {false, false, true, true, false, false, false, false},
                {false, false, false, true, true, false, false, false},
                {false, false, false, false, true, true, false, false},
                {false, false, false, false, false, true, true, false},
                {false, false, false, false, false, false, true, true}
            };
        problems[1].intervalPatterns1 = new boolean[][]
            {
                {true, false, false, false, false, false, false, false},
                {false, true, false, false, false, false, false, false},
                {false, false, true, false, false, false, false, false},
                {false, false, false, true, false, false, false, false},
                {false, false, false, false, true, false, false, false},
                {false, false, false, false, false, true, false, false},
                {false, false, false, false, false, false, true, false},
                {false, false, false, false, false, false, false, true}
            };
        problems[1].unitTypes = new boolean[][][]
            {
                problems[1].intervalPatterns2,
                problems[1].intervalPatterns2,
                problems[1].intervalPatterns2,
                problems[1].intervalPatterns2,
                problems[1].intervalPatterns2,
                problems[1].intervalPatterns2,
                problems[1].intervalPatterns1,
                problems[1].intervalPatterns1,
                problems[1].intervalPatterns1,
                problems[1].intervalPatterns1,
                problems[1].intervalPatterns1,
                problems[1].intervalPatterns1,
                problems[1].intervalPatterns1,
                problems[1].intervalPatterns1,
                problems[1].intervalPatterns1
            }; 
        problems[1].unitCapacity = new double[]{20, 15, 35, 40, 15, 15, 20, 25, 22, 36, 15, 22, 27, 45, 15};
        problems[1].intervalLoads = new double[]{210, 230, 195, 220, 250, 205, 215, 195};
        problems[1].totalCapacity = 0.0;
        problems[1].sizes = new int[problems[1].nUnits];
        for(int unit = 0; unit < problems[1].nUnits; unit++)
        {
            problems[1].totalCapacity += problems[1].unitCapacity[unit];
            problems[1].sizes[unit] = problems[1].unitTypes[unit].length;
        }
    }
    
    public int nUnits;
    public int nIntervals;
    private boolean[][] intervalPatterns2;
    private boolean[][] intervalPatterns1;          
    public boolean[][][] unitTypes;           
    public double[] unitCapacity;
    public double[] intervalLoads;
    public int[] sizes;
    public double totalCapacity;
 }
