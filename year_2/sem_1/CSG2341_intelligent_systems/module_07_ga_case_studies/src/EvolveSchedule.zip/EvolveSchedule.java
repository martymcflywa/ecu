import Evolution.*;

import java.util.*;

/**
 * Driver class for a genetic algorithm to solve scheduling
 * problems like the one in the text book, section 7.5.
 * 
 * @author (phi) 
 * @version (2003/2)
 */
public class EvolveSchedule
{
    /**
     * The driver. Creates an object and calls its go() method.
     */
    public static void main(String[] args)
    {
        EvolveSchedule evolver = new EvolveSchedule();
        
        try
        {
            evolver.go();
        }
        catch(Exception e)
        {
            e.printStackTrace(System.out);
        }
    }
    
    /**
     * A method that creates and runs the GA
     */
    public void go() throws EvolutionException
    {
        // create a random number generator
        Random random = new Random();
        // and a problem instance
        ScheduleProblem problem =
                        ScheduleProblem.getScheduleProblem(PROBLEM);
        
        // Create an array of objects. These objects will be used as
        // parameters for the constructor of the
        // EvolvableSchedule class       
        Object[] constructorParams = {random, problem};
        
        // Create a genetic algorithm instance
        GeneticAlgorithm ga = new GeneticAlgorithm
            (
                EvolvableSchedule.class, // class of evolvable objects
                constructorParams,       // parameters for constructor
                POPSIZE,                 // population size
                random,                  // random number generator
                1.0/(problem.nUnits),    // mutation probability
                CROSSOVER,               // crossover probability
                // the object that evaluates fitness
                new ScheduleEvaluator(problem),
                // and the object that determines when to stop
                new GenerationsTerminator(GENERATIONS),
                // next we have the selection method for the GA
                new StochasticUniformSelector(random),
                true // whether to use elitism or not
            );

        // create and show a frame for the user to control and
        // visualise the algorithm solving the problem
        ga.display();
    }
    
    public static final int PROBLEM = 0; // 0 is easy, 1 is harder
    public static final int GENERATIONS = 250;
    public static final int POPSIZE = 100;
    public static final double CROSSOVER = 0.6;
}
