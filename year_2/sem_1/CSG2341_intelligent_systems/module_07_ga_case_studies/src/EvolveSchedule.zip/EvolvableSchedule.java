import Evolution.*;

import java.util.Random;
import java.awt.geom.*;
import java.awt.*;

/**
 * A class for an Evolvable object representing a maintenance schedule.
 * 
 * @author (phi) 
 * @version (2003/2)
 */
public class EvolvableSchedule extends DiscreteEvolvable
{
    /**
     * Constructor for an evolvable schedule
     * 
     * @param random a random number generator
     * @param problem a problem instance
     * 
     */
    public EvolvableSchedule(Random random, ScheduleProblem problem)
    {
        super(random, problem.sizes, EvolutionaryAlgorithm.TWOPOINT);

        this.problem = problem;

        schedule = new boolean[problem.nUnits][problem.nIntervals];
        available = new double[problem.nIntervals];
        
        leftAxis = new EAGraphAxis();
        leftAxis.addValue(0);
        leftAxis.addValue(problem.totalCapacity);
    }
    
    /**
     * Method to develop the phenotype of the evolvable schedule
     * 
     */
    public void develop()
    {
        // each element of the genome is an index into an array of allowed
        // maintenance patterns for the corresponding unit
        for(int unit = 0; unit < problem.nUnits; unit++)
        {
            // copy the chosen pattern into the schedule
            System.arraycopy(problem.unitTypes[unit][chromosome[unit]], 0,
                             schedule[unit], 0, problem.nIntervals);
        }
        
        // also compute an array of available reserves for each interval
        for(int i = 0; i < problem.nIntervals; i++)
        {
            available[i] = 0.0;
            for(int j = 0; j < problem.nUnits; j++)
            {
                if(!schedule[j][i])
                {
                    available[i] += problem.unitCapacity[j];
                }
            }
        }
    }
    
    /**
     * Access method for the schedule
     * 
     * @return the schedule as an array of maintenance patterns
     */
    public boolean[][] getSchedule()
    {
        return schedule;
    }
    
    /**
     * A method that draws a graphical version of the schedule.
     * Used when a run of an evolutionary algorithm needs to display a solution
     * 
     * @param gr the graphics context to draw into
     * @param viewport where to draw the graphics
     * 
     */
    public void draw(Graphics gr, Rectangle viewport)
    {
        Graphics2D g = (Graphics2D)gr;
        
        final int LEFTGAP = 100;
        final int TOPGAP =50;
        final int BOTTOMGAP = 50;
        final int GAP = 20;
        final double WIDTH = (viewport.width-LEFTGAP)/problem.nIntervals - GAP;
        final double HEIGHT = viewport.height - TOPGAP - BOTTOMGAP;
                
        g.setColor(Color.white);
        g.fill(viewport);
        
        g.setColor(Color.black);
        g.drawString("Net reserves:", (int)Math.round(viewport.x+viewport.width/2), 15);
        g.drawString("Time interval", (int)Math.round(viewport.x+viewport.width/2), (int)Math.round(viewport.y+viewport.height-15));
        
        g.setColor(Color.black);
        double[] ticks = leftAxis.getTicks();
        double axisHeight = leftAxis.getWidth();
        String[] labels = leftAxis.getLabels();

         g.drawLine(LEFTGAP-25, (int)Math.round(viewport.y+viewport.height-BOTTOMGAP),
                    LEFTGAP-25, (int)Math.round(viewport.y+viewport.height-BOTTOMGAP-HEIGHT));
         for(int i = 0; i < ticks.length; i++)
         {
            g.drawLine(LEFTGAP-25, (int)Math.round(viewport.y+viewport.height-BOTTOMGAP-HEIGHT*(ticks[i]-ticks[0])/axisHeight),
                       LEFTGAP-40, (int)Math.round(viewport.y+viewport.height-BOTTOMGAP-HEIGHT*(ticks[i]-ticks[0])/axisHeight));
            g.drawString(labels[i], 25, (int)Math.round(viewport.y+viewport.height-BOTTOMGAP-HEIGHT*(ticks[i]-ticks[0])/axisHeight-5));
         }

        for(int interval = 0; interval < problem.nIntervals; interval++)
        {
            int x = (int)Math.round(viewport.x+LEFTGAP+interval*(WIDTH+GAP));
            
            g.setColor(Color.black);
            g.drawString(""+(available[interval]-problem.intervalLoads[interval]), x+5, TOPGAP-10);
            g.drawString(""+(interval+1), x+5, (int)Math.round(viewport.y+viewport.height-BOTTOMGAP+15));
            
            g.setColor(Color.darkGray);
            final double loadH = HEIGHT*problem.intervalLoads[interval]/problem.totalCapacity;
            g.fillRect(x, (int)Math.round(viewport.y+viewport.height-BOTTOMGAP-loadH),
                        (int)Math.round(WIDTH), (int)Math.round(loadH));
            double SCHEDULED = 0.0;
            for(int unit = 0; unit < problem.nUnits; unit++)
            {
                if(schedule[unit][interval])
                {
                    double h = HEIGHT*problem.unitCapacity[unit]/problem.totalCapacity;
                    SCHEDULED += h;
                }
            }
            g.setColor(Color.cyan);
            g.fillRect(x, (int)Math.round(viewport.y+TOPGAP),
                        (int)Math.round(WIDTH), (int)Math.round(SCHEDULED));
        }
        for(int interval = 0; interval < problem.nIntervals; interval++)
        {
            int x = (int)Math.round(viewport.x+LEFTGAP+interval*(WIDTH+GAP));           
            double loadH = HEIGHT*problem.intervalLoads[interval]/problem.totalCapacity;
            g.setColor(Color.black);
            g.drawRect(x, (int)Math.round(viewport.y+TOPGAP),
                        (int)Math.round(WIDTH), (int)Math.round(HEIGHT));
            double TOP = viewport.y+TOPGAP;
            for(int unit = 0; unit < problem.nUnits; unit++)
            {
                if(schedule[unit][interval])
                {
                    double h = HEIGHT*problem.unitCapacity[unit]/problem.totalCapacity;
                    g.setColor(Color.blue);
                    g.drawString("Unit " + (unit+1), x+5, (int)Math.round(TOP+10)); 
                    g.setColor(Color.black);
                    g.drawLine(x, (int)Math.round(TOP+h), (int)Math.round(x+WIDTH), (int)Math.round(TOP+h));
                    TOP += h;
                }
            }
        }        
    }
    
    /**
     * Returns a textual description of the schedule
     * 
     * @return the description
     * 
     */
    public String toString()
    {
        String result = "";

        for(int i = 0; i < problem.nIntervals; i++)
        {
            result += "Interval " + i + ", active units : ";
            for(int j = 0; j < problem.nUnits; j++)
            {
                if(!schedule[j][i])
                {
                    result += "unit " + j + "(" + problem.unitCapacity[j] + ") ";
                }
            }
            result += "\n";
        }
        
        return result;
    }
 
    private ScheduleProblem problem; // the problem instance to solve
    private boolean[][] schedule;   // the schedule, as an array of maintenance patterns, indexed by unit
    private double[] available;     // available reserves, indexed by interval
    private EAGraphAxis leftAxis;   // the left axis showing capacity values in the graphical depiction of the schedule
}
