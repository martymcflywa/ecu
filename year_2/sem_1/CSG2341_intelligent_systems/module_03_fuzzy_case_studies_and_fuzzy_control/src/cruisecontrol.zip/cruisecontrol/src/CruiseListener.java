
/**
 * Interface for a class that wants to listen to a cruise controller
 *
 * @author phi
 * @version 1
 */

public interface CruiseListener
{
    public void update();
}
