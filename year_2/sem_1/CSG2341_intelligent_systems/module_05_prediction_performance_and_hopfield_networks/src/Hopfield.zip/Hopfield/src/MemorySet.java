
/**
 * A class that supplies a set of memories to be stored in a Hopfield network
 * 
 * @author phi
 * @version 2003/2
 */
public class MemorySet
{
    private MemorySet(int width, int height, String[] names)
    {
        memories = new double[names.length][width*height];
        
        this.width = width;
        this.height = height;
        this.names = names;
    }
    
    public static MemorySet getSampleMemories()
    {
        MemorySet sample = new MemorySet(21, 21, new String[]{"t", "s", "c", "cb"});
        
        // filled triangle
        for(int i = 0; i < 21*21; i++)
        {
            sample.memories[0][i] = OFF;
        }
        for(int i = 0; i < 20; i++)
        {
            for(int j = 10-i/2; j <= 10+i/2; j++)
            {
                sample.memories[0][i*21+j] = ON;
            }
        }
        
        // hollow square
        for(int i = 0; i < 21*21; i++)
        {
            sample.memories[1][i] = OFF;
        }
        for(int i = 0; i < 2*21; i++)
        {
            sample.memories[1][i] = ON;
            sample.memories[1][21*19+i] = ON;
        }
        for(int i = 0; i < 21; i++)
        {
            sample.memories[1][21*i] = ON;
            sample.memories[1][21*i+1] = ON;
            sample.memories[1][21*i+19] = ON;
            sample.memories[1][21*i+20] = ON;
        }
        
        // hollow circle
        for(int i = 0; i < 21*21; i++)
        {
            sample.memories[2][i] = OFF;
        }
        for(double theta = 0.0; theta < 2.0*Math.PI; theta += 0.01)
        {
            int x = 10 + (int)Math.round(10*Math.sin(theta));
            int y = 10 + (int)Math.round(10*Math.cos(theta));
            
            sample.memories[2][21*x + y] = ON;
        }
        
        // chess board
        for(int i = 0; i < 21; i++)
        {
            for(int j = 0; j < 21; j++)
            {
                sample.memories[3][21*i+j] = ((i+j)%2==0)? ON: OFF;
            }
        }
        
        return sample;
    }
    
    public int getWidth()
    {
        return width;
    }
    
    public int getHeight()
    {
        return height;
    }
    
    public int getCount()
    {
        return names.length;
    }
    
    public String getName(int i)
    {
        return names[i];
    }
    
    public double[] getMemory(int i)
    {
        return memories[i];
    }
    
    private double[][] memories;
    private int width;
    private int height;
    private String[] names;
    
    private static final double OFF = -1.0;
    private static final double ON = 1.0;
}
