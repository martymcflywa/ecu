
/**
 * An interface for classes that listen to Hopfild networks
 * 
 * @author phi
 * @version 2003/2
 */
public interface HopfieldListener
{
    public void setEnergy(double energy);
}
