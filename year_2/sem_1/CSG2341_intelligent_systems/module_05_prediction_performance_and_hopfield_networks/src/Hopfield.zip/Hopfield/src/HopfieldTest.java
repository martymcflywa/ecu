import au.edu.ecu.is.neural.*;

import javax.swing.*;
import java.awt.*;
import java.awt.event.*;

import java.util.*;

/**
 * A class to test a Hopfield network being used as an associate memory
 * 
 * @author phi
 * @version 2003/2
 */
public class HopfieldTest extends JPanel
{
    public static void main(String[] args) throws Exception
    {
        HopfieldTest test = new HopfieldTest();
        
        test.display();
    }
    
    public HopfieldTest() throws Exception
    {
        // get some memories
        memories = MemorySet.getSampleMemories();
        
        // create the network
        Random random = new Random();
        final int patWidth = memories.getWidth();
        final int patHeight = memories.getHeight();
        network = new HopfieldNetwork(patWidth*patHeight, random, HopfieldNetwork.DETERMINISTIC);
        network.setShape(patWidth, patHeight);
        network.setDelay(1000);
        
        // load in "memories" to store in the network
        for(int i = 0; i < memories.getCount(); i++)
        {
            network.addMemory(memories.getMemory(i));
        }
        
        // set up size and layout for the panel
        setPreferredSize(new Dimension(700, 900));
        setLayout(new BorderLayout());
        
        // the network display goes in the middle
        add(network, BorderLayout.CENTER);
        
        // add a panel of control buttons
        JPanel control = new JPanel();
            // add buttons to set activation patterns
            PatternButton[] patternButtons = new PatternButton[memories.getCount()];
            for(int i = 0; i < memories.getCount(); i++)
            {
                patternButtons[i] = new PatternButton(i, memories.getName(i));
                control.add(patternButtons[i], BorderLayout.SOUTH);
            }
                        
            // one to add noise
            CorruptButton corruptButton = new CorruptButton();
            control.add(corruptButton, BorderLayout.SOUTH);
            
            // one to randomise
            RandomiseButton randomiseButton = new RandomiseButton();
            control.add(randomiseButton, BorderLayout.SOUTH);
            
            // one to do a single update
            StepButton stepButton = new StepButton();
            control.add(stepButton, BorderLayout.SOUTH);
            
            // and one to start the "computation"
            RelaxButton relaxButton = new RelaxButton();
            control.add(relaxButton, BorderLayout.SOUTH);
        add(control, BorderLayout.SOUTH);
        
        EnergyButton energyButton = new EnergyButton();
        network.addListener(energyButton);
        add(energyButton, BorderLayout.NORTH);
    }

    /**
     * Display the panel in its own JFrame.
     */
    public void display()
    {
        JFrame viewer = new JFrame("Hopfield network tester");
        viewer.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        viewer.getContentPane().add(this);
        viewer.pack();
        viewer.show();
    }
    
    /**
     * Set the activation pattern of hte network to match one of the patterns
     * 
     * @param i the index of the pattern
     */
    public void setPattern(int i)
    {
        double[] pattern = memories.getMemory(i);
        synchronized(network)
        {
            network.setPattern(pattern);
        }
    }
    
    // buttons that set the activation levels of hte network
    // to match one of the patterns
    private class PatternButton extends JButton implements ActionListener
    {
        public PatternButton(int i, String name)
        {
            setText(name);
            this.i = i;
            
            addActionListener(this);
        }
        
        public void actionPerformed(ActionEvent e)
        {
            setPattern(i);
        }
        
        private int i;
    }
    
    // a button to an random noise to the network's activation levels
    private class CorruptButton extends JButton implements ActionListener
    {
        public CorruptButton()
        {
            setText("corrupt");
            
            addActionListener(this);
        }
        
        public void actionPerformed(ActionEvent e)
        {
            synchronized(network)
            {
                network.corrupt(0.05);
            }
        }
    }

    // a button to randomise the network's activation levels
    private class RandomiseButton extends JButton implements ActionListener
    {
        public RandomiseButton()
        {
            setText("random");
            
            addActionListener(this);
        }
        
        public void actionPerformed(ActionEvent e)
        {
            synchronized(network)
            {
                network.randomise();
            }
        }
    }

    // a button to carry out one update
    private class StepButton extends JButton implements ActionListener
    {
        public StepButton()
        {
            setText("step");
            
            addActionListener(this);
        }
        
        public void actionPerformed(ActionEvent e)
        {
            network.updateAsynch();
        }
    }

    // a button to start the network's relaxation
    private class RelaxButton extends JButton implements ActionListener
    {
        public RelaxButton()
        {
            setText("relax");
            
            addActionListener(this);
        }
        
        public void actionPerformed(ActionEvent e)
        {
            network.relax();
        }
    }

    // a label to display the network's energy level
    private class EnergyButton extends JButton implements HopfieldListener
    {
        public void setEnergy(double energy)
        {
            setText(""+energy);
        }
    }
    
    private HopfieldNetwork network;
    private MemorySet memories;
}
