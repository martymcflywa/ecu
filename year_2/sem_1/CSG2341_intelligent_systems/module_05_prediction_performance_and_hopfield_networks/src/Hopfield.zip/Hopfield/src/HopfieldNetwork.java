import au.edu.ecu.is.neural.*;

import javax.swing.*;
import java.awt.*;
import java.awt.event.*;

import java.util.*;

/**
 * A fast and dirty implementation of a Hopfield network.
 * 
 * @author phi 
 * @version 2004/2
 */
public class HopfieldNetwork extends JPanel implements Runnable
{
    /**
     * Constructor for a Hopfield network 
     * 
     * @param size is the number of neurons in the network
     * @param random is a random number generator
     * @param type is 0 for deterministic neurons, 1 for thermal neurons
     * 
     * @throws Exception
     */
    public HopfieldNetwork(int size, Random random, int type) throws Exception
    {
        this.size = size;
        this.random = random;
        this.type = type;
        
        // create the neurons        
        neurons = new Neuron[size];
        for(int i = 0; i < size; i++)
        {
            if(type == DETERMINISTIC)
            {
                neurons[i] = new HopfieldNeuron();
            }
            else
            {
                neurons[i] = new ThermalHopfieldNeuron(random);
            }
        }
        // create an array of buttons, one per neuron, to use for display
        neuronButtons = new NeuronButton[size];
        for(int i = 0; i < size; i++)
        {
            neuronButtons[i] = new NeuronButton();
            add(neuronButtons[i]);
        }

        // the buttons are arranged in a grid for display
        // the shape of the grid can be changed
        setShape(size, 1);
        
        // connect every neuron to every other neuron
        // keep the connections in an array for later
        connections = new Connection[size][size];
        for(int i = 0; i < size; i++)
        {
            for(int j = 0; j < i; j++)
            {
                connections[i][j] = neurons[j].connectFrom(neurons[i],  0.0);
                connections[j][i] = neurons[i].connectFrom(neurons[j], 0.0);
            }
            connections[i][i] = neurons[i].connectFrom(neurons[i], 0.0);
        }

        // used for randomizing the order in which neurons are updated
        order = new int[size];
        
        // a list of listeners
        listeners = new Vector();
    }
    
    /**
     * Display the panel in its own JFrame.
     */
    public void display()
    {
        JFrame viewer = new JFrame("Hopfield network viewer");
        viewer.getContentPane().add(this);
        viewer.pack();
        viewer.show();
    }

    /**
     * Arranges the neurons in a grid for display 
     * 
     * @param shapeWidth     the grid width
     * @param shapeHeight    the grid height
     * 
     * @throws Exception if the grid size doesn't match the width and height
     */
    public void setShape(int shapeWidth, int shapeHeight) throws Exception
    {
        if(shapeWidth*shapeHeight != size)
        {
            throw new Exception("Shape does not match size");
        }
        
        this.shapeWidth = shapeWidth;
        this.shapeHeight = shapeHeight;
        
        setLayout(new GridLayout(shapeHeight, shapeWidth));
        
        validate();
    }
    
    // methods that describe how the network "computes"
    
    /**
     * The network operates by "relaxing" into a low energy state 
     */
    public void relax()
    {
       (new Thread(this)).start();
    }
    
    /**
     * Relaxing is done in a separate thread
     * This makes animation easier
     * 
     */
    public void run()
    {
        synchronized(this)
        {
            boolean changed = true;
            int cycles = 0;
            
            while(changed && cycles < MAXCYCLES)
            {
                changed = updateAsynch();
                repaint();
                cycles++;
                
                if(delay > 0)
                {
                    try
                    {
                        Thread.sleep(delay);
                    }
                    catch(Exception e){}
                }
            }
        }
    }
    
    /**
     * Set the delay to use between cycles when the network is relaxing
     * 
     * @param delay the delay in milliseconds
     */
    public void setDelay(int delay)
    {
        this.delay = delay;
    }
    
    /**
     * Carry out one cycle of neuron updates
     * The neurons are updated asynchronously in random order
     * Another variation is to use synchronous updates (i.e.e all neurons update simultaneously)
     */
    public boolean updateAsynch()
    {
        boolean changed = false;
        
        for(int i = 0; i < size; i++)
        {
            order[i] = i;
        }
        
        for(int i = 0; i < size; i++)
        {
            int index = random.nextInt(size-i);
            int choice = order[index];
            
            double oldAct = neurons[choice].getOutput();
            neurons[choice].update();
            double newAct = neurons[choice].getOutput();
            neuronButtons[choice].setActivation(newAct);
            
            changed |= (oldAct != newAct);
            order[index] = order[size-i-1];
        }

        updateListeners();
        
        return changed;
    }

    /**
     * Calculate the thermal energy of the network
     * this quantity always decreases when a neuron is deterministically updated
     * 
     * @return the energy
     */
    public double getEnergy()
    {
        double energy = 0.0;
        
        for(int i = 0; i < size; i++)
        {
            for(int j = 0; j < size; j++)
            {
                energy -= connections[i][j].getWeight()*neurons[i].getOutput()*neurons[j].getOutput();
            }
        }
        
        return energy;
    }
 
    // methods to set activation levels of neurons
    
    /**
     * Sets the activation level of an individual neuron
     * 
     * @param act the activation level
     * @param i the index of the neuron
     */
    private void setActivation(double act, int i)
    {
        neurons[i].setActivation(act);
        neuronButtons[i].setActivation(act);
        
        updateListeners();
    }
    
    /**
     * Set the activation of all neurons randomly to +1 or -1
     * 
     */
    public void randomise()
    {
        for(int i = 0; i < size; i++)
        {
            setActivation(random.nextInt(2) == 0? 1.0: -1.0, i);
        }
    }
    
    /**
     * Set a patricular pattern of activation levels over all the neurons
     * 
     * @param patterns an array of activation levels
     */
    public void setPattern(double[] pattern)
    {
        // pattern values should be -1 or +1
        for(int i = 0; i < size; i++)
        {
            setActivation(pattern[i], i);
        }
    }
    
    /**
     * Disrupt the pattern of activation values by randomly flipping some
     * neurons
     * 
     * @param prob the probability for flipping each neuron
     */
    public void corrupt(double prob)
    {
        for(int i = 0; i < size; i++)
        {
            if(random.nextDouble() < prob)
            {
                double old = neurons[i].getOutput();
                setActivation((old == -1.0)? 1.0: -1.0, i);
            }
        }
    }

    // methods for setting connection weights
    
    /**
     * Set one weight
     * 
     * @param i one end of the connection
     * @param j the other end
     * @param weight the weight value for the connection
     */
    public void setWeight(int i, int j, double weight)
    {
        connections[i][j].setWeight(weight);
        connections[j][i].setWeight(weight);
    }

    /**
     * Erase any memories by setting all the weights to zero
     * 
     */
    public void zeroWeights()
    {
        for(int i = 0; i < size; i++)
        {
            for(int j = 0; j < size; j++)
            {
                connections[i][j].setWeight(0.0);
            }
        }
    }
    
    /**
     * Adjust the weights of the network to store a new memory
     * 
     * @param pattern is the new memory to store
     */
    public void addMemory(double[] pattern)
    {
        // pattern values should be -1 or +1
        for(int i = 0; i < size; i++)
        {
            for(int j = 0; j < size; j++)
            {
                if(i != j)
                {
                    connections[i][j].setWeight(connections[i][j].getWeight() + pattern[i]*pattern[j]);
                }
            }
        }
    }
    
    public void setTemperature(double temperature)
    {
        this.temperature = temperature;
        
        if(type == THERMAL)
        {
            for(int i = 0; i < size; i++)
            {
                ((ThermalHopfieldNeuron)neurons[i]).setTemperature(temperature);
            }
        }
    }
    
    // listener methods

    public void addListener(HopfieldListener listener)
    {
        listeners.add(listener);
    }
    
    public void updateListeners()
    {
        if(listeners.size() > 0)
        {
            double energy = getEnergy();
            
            Enumeration e = listeners.elements();
            
            while(e.hasMoreElements())
            {
                HopfieldListener listener = (HopfieldListener)e.nextElement();
                
                listener.setEnergy(energy);
            }
        }
    }
    
    // an inner class to buttons used to represent neurons in a display
    private class NeuronButton extends JButton
    {        
        public void setActivation(double act)
        {
            // -1 <= act <= 1
            // at the moment, act is always either -1 or +1, but
            // other varieties of Hopfield networks can have continuous valued neurons
            float grey = (float)(0.5*(act+1));
            
            setBackground(new Color(grey, grey, grey));
        }
    }
    
    public Random random;
    public int size;
    public int shapeWidth;
    public int shapeHeight;
    public Neuron[] neurons;
    public NeuronButton[] neuronButtons;
    public Connection[][] connections;
    public int type;
    public double temperature;
    public int order[];
    public int delay = 500;
    public Vector listeners;
    
    public static final int DETERMINISTIC = 0;
    public static final int THERMAL = 1;
    public static final int MAXCYCLES = 10000;  // a limit on how many updates are allowed when relaxing the network
}
