
package EvolveFuzzyCruiseControl;

import CruiseControl.*;
import au.edu.ecu.is.fuzzy.*;

/**
 *
 * @author CSG2341
 * @version 2015/2
 */
public interface FuzzyCruiseController extends CruiseController
{
    public FuzzyRuleSet getRuleSet();

    public FuzzyVariable getSpeedError();
    
    public FuzzyVariable getAcceleration();
    
    public FuzzyVariable getForceChange();
    
}
