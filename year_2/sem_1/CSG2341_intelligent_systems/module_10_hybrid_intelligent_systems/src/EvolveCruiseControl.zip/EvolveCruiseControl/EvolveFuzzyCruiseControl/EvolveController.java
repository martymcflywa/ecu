package EvolveFuzzyCruiseControl;
import CruiseControl.CruiseEvaluator;
import CruiseControl.*;
import au.edu.ecu.is.evolution.*;
import au.edu.ecu.is.fuzzy.*;

import java.util.*;

/**
 * A driver program to fine-tune a cruise controller by evolution
 * 
 * @author CSG2341
 * @version 2015/2
 */
public class EvolveController
{
    public static void main(String[] args)
    {
        EvolveController evolver = new EvolveController();
        
        try
        {
            evolver.go();
        }
        catch(Exception e)
        {
            e.printStackTrace(System.out);
        }
    }
    
    public void go() throws Exception
    {
        final double MASS = 1000.0;
        final double FRICTION = 10.0;
        final double MAXFORCE = 5000;
        final double MINH = 3.0;
        final double MAXH = 30.0;
        final double MINL = 300.0;
        final double MAXL = 500.0;
        final double WINDOWWIDTH = 1200.0;
        final double TARGET = 15.0;

        setup = new CruiseControlSetup(MASS, FRICTION, MAXFORCE, MINH, MAXH, MINL, MAXL, WINDOWWIDTH, TARGET);
        controller = new MyCruiseController(setup.getCar(), TARGET);
        ruleset = controller.getRuleSet(); 
        evaluator = new CruiseEvaluator(setup, controller, STEPS, TRIALS);
        Random random = new Random();
               
        // parameters for the constructor of the Evolvable objects
        //
        // The Evolvable is a FuzzyRuleSetGenome, which can be used to evolve parameters for a FuzzyRuleSet
        //
        Object[] constructorParams = 
            {
                ruleset,    // the rule set to use as a template
                random,
                new Double(MUTATIONRATE),
                new Integer(EvolutionaryAlgorithm.ONEPOINT)
            };
            
        ea = new GeneticAlgorithm
            (
                FuzzyRuleSetGenome.class,
                constructorParams,
                POP,
                random,
                MUTATIONPROB,
                CROSSOVERPROB,
                evaluator,
                new GenerationsTerminator(GENERATIONS),
                new StochasticUniformSelector(random),
                true
            );

        // this listener is used to pop up a tester when the evolution is done        
        ea.addListener(new Reporter());
        
        //ea.test();        
        
        ea.display();
    }

    class Reporter implements EAListener
    {
        public void adviseInit(){}
        public void adviseUpdate(){}
        public void adviseDone()
        {
            try
            {
                evaluator.printStats(ea.getBestEver());
                
                FuzzyRuleSetGenome frs = (FuzzyRuleSetGenome)ea.getBestEver();
                frs.copyToRuleSet();    // copies genome data to controller ruleset
                CruiseControlTest tester = new CruiseControlTest(setup, controller); 
                tester.display();
            }
            catch(Exception e)
            {
                System.out.println(e.getMessage());
                System.exit(0);
            }
        }
    }
    
    private static final int STEPS = 1000;
    private static final int TRIALS = 10;
    private static final int GENERATIONS = 250;
    private static final int POP = 25;
    private static final double CROSSOVERPROB = 0.7;
    private static final double MUTATIONPROB = 0.1;
    private static final double MUTATIONRATE = 0.05;
        
    private EvolutionaryAlgorithm ea;
    private FuzzyRuleSet ruleset;
    private CruiseControlSetup setup;
    private FuzzyCruiseController controller;
    private CruiseEvaluator evaluator;
}
