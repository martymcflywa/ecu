package CruiseControl;
import java.util.*;
import java.awt.*;
import java.awt.geom.*;

/**
 * Set up a cruise control scenario
 * 
 * @author CSG2341
 * @version 2015/2
 */
public class CruiseControlSetup
{
    public CruiseControlSetup(double carMass, double carFriction, double carMaxPower, double minHillAmplitude, double maxHillAmplitude,
                double minHillLength, double maxHillLength, double width, double targetSpeed)
    {
        random = new Random();
        
        car = new Car(carMass, carFriction, carMaxPower);
        maxForce = car.getMaxForce();
        minForce = -car.getMaxForce();
        
        this.minHillAmplitude = minHillAmplitude;
        this.maxHillAmplitude = maxHillAmplitude;
        this.minHillLength = minHillLength;
        this.maxHillLength = maxHillLength;
        
        this.width = width;
        this.height = 2.0*maxHillAmplitude;
        
        nHills = (int)(0.5+width/minHillLength);
        hills = new Hill[nHills];
        for(int i = 0; i < nHills; i++)
        {
            hills[i] = new Hill(0.0, 0.0, 0.0);
        }
        
        this.targetSpeed = targetSpeed;
        
        listeners = new Vector();
        
        init();
    }
    
    public void init()
    {
        double startX = -width/2.0;
        for(int i = 0; i < nHills; i++)
        {
            startX = configureHill(hills[i], startX);
        }
        
        car.setX(0.0);
        car.setV(targetSpeed);
        force = car.getConstantSpeedForce(getTheta(car.getX()), targetSpeed);
        acceleration = 0.0;
        
        nVals = 0;
        addVal();
    }
    
    public Car getCar()
    {
        return car;
    }
    
    public double getX()
    {
        return car.getX();
    }
    
    public double getV()
    {
        return car.getV();
    }
    
    public double getSpeedError()
    {
        return car.getV() - targetSpeed;
    }
    
    public double getA()
    {
        return acceleration;
    }
    
    public double getForce()
    {
        return force;
    }
    
    public double getTarget()
    {
        return targetSpeed;
    }
    
    public void update(double forceChange, double tick)
    {
        Enumeration e = listeners.elements();
        while(e.hasMoreElements())
        {
            ((CruiseListener)e.nextElement()).update();
        }
        
        force += forceChange;
        
        double v = car.getV();
        car.update(force, getTheta(car.getX()), tick);
        acceleration = (car.getV() - v)/tick;
        
        while(hills[0].getStartX()+hills[0].getLength() < car.getX() - width/2)
        {
            addHill();
        }
        
        addVal();
    }
    
    private void addVal()
    {
        if(nVals == MAXVALS)
        {
            System.arraycopy(xVals, 1, xVals, 0, MAXVALS-1);
            System.arraycopy(vVals, 1, vVals, 0, MAXVALS-1);
            System.arraycopy(fVals, 1, fVals, 0, MAXVALS-1);
            
            nVals--;
        }
        
        xVals[nVals] = car.getX();
        vVals[nVals] = car.getV();
        fVals[nVals] = force;
        
        nVals++;
    }
    
    private void addHill()
    {
        Hill save = hills[0];
        
        System.arraycopy(hills, 1, hills, 0, nHills-1);
        
        configureHill(save, hills[nHills-1].getStartX()+hills[nHills-1].getLength());
        hills[nHills-1] = save;
    }
    
    private double getTheta(double x)
    {
        // find right hill
        int i = 0;
        while(x > hills[i].getStartX()+hills[i].getLength()) i++;
        
        return hills[i].getTheta(x);
    }

    private double configureHill(Hill hill, double hillStart)
    {
        hill.setStartX(hillStart);
        hill.setAmplitude(minHillAmplitude + random.nextDouble()*(maxHillAmplitude-minHillAmplitude));
        hill.setLength(minHillLength + random.nextDouble()*(maxHillLength-minHillLength));
        
        return hillStart + hill.getLength();
    }
    
    public void draw(Graphics g, Rectangle2D.Double viewport)
    {
        Rectangle2D.Double subViewport = new Rectangle2D.Double(0.0, 0.0, 0.0, 0.0);
        double x = car.getX();
        
        for(int i = 0; i < nHills; i++)
        {
            Rectangle2D.Double window = hills[i].getWindow();
            
            subViewport.x = viewport.x + viewport.width*(window.x-x+width/2)/width;
            subViewport.y = viewport.y - viewport.height/2 - viewport.height*(window.y+maxHillAmplitude)/(2*height);
            subViewport.width = viewport.width*window.width/width;
            subViewport.height = viewport.height*window.height/(2*height);

            hills[i].draw(g, subViewport, car.getX());
            
            g.setColor(Color.white);
            g.fillRect((int)viewport.x, (int)(viewport.y-viewport.height/2), (int)viewport.width, (int)(viewport.height/2));
            
            g.setColor(Color.yellow);
            g.drawLine((int)(viewport.x),
                        (int)(viewport.y - viewport.height/4),
                        (int)(viewport.x + viewport.width),
                        (int)(viewport.y - viewport.height/4));
            
            double prevX = xVals[0];
            double prevV = vVals[0];
            double prevF = fVals[0];
            for(int j = 1; j < nVals; j++)
            {
                g.setColor(Color.blue);
                g.drawLine((int)(viewport.x + viewport.width*(prevX-x+width/2)/width),
                            (int)(viewport.y - viewport.height*(prevV)/(4*targetSpeed)),
                            (int)(viewport.x + viewport.width*(xVals[j]-x+width/2)/width),
                            (int)(viewport.y - viewport.height*(vVals[j])/(4*targetSpeed)));
                g.setColor(Color.green);
                g.drawLine((int)(viewport.x + viewport.width*(prevX-x+width/2)/width),
                            (int)(viewport.y - viewport.height*(prevF-minForce)/(2*(maxForce-minForce))),
                            (int)(viewport.x + viewport.width*(xVals[j]-x+width/2)/width),
                            (int)(viewport.y - viewport.height*(fVals[j]-minForce)/(2*(maxForce-minForce))));
                prevX = xVals[j];
                prevV = vVals[j];
                prevF = fVals[j];
            }
        }
    }
    
    public void addListener(CruiseListener listener)
    {
        listeners.add(listener);
    }
      
    private final Car car;
    private final Hill[] hills;
    private final int nHills;
    private final double minHillAmplitude;
    private final double maxHillAmplitude;
    private final double minHillLength;
    private final double maxHillLength;
    private final double width;
    private final double height;
    private final double targetSpeed;
    private final double maxForce;
    private final double minForce;

    private final Random random;
    
    private static final int MAXVALS = 200;
    private final double[] xVals = new double[MAXVALS];
    private final double[] vVals = new double[MAXVALS];
    private final double[] fVals = new double[MAXVALS];
    private int nVals = 0;
    private double acceleration;
    
    private final Vector listeners;
    
    private double force;
}
