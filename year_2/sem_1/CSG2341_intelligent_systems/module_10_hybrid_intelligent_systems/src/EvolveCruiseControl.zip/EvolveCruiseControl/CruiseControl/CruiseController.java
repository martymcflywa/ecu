package CruiseControl;
import au.edu.ecu.is.evolution.Evolvable;

/**
 * Interface for CruiseController
 * 
 * @author CSG2341
 * @version 2015/2
 */
public interface CruiseController
{
    public void load(Evolvable evolvable);
    
    public double computeForceChange(double speedError, double acceleration);
}
