package CruiseControl;
import CruiseControl.*;
import au.edu.ecu.is.evolution.*;
import au.edu.ecu.is.fuzzy.*;


/**
 * An evaluator for an evolutionary algorithm to evolve a cruise controller.
 * 
 * @author CSG2341
 * @version 2015/2
 */
public class CruiseEvaluator extends Evaluator
{
    public CruiseEvaluator(CruiseControlSetup setup, CruiseController controller, int steps, int trials)
    {
        this.setup = setup;
        this.controller = controller;
        this.steps = steps;
        this.trials = trials;
    }
    
    // estimate the fitness of a controller with evolved shapes and other parameters
    public double evaluate(Evolvable evolvable)
    {
        // load the parameters into the controller
        controller.load(evolvable);

        // simulate the setup for steps timesteps, trials times

        totalError = 0.0;
        totalOK = 0;
        totalForce = 0.0;
            
        for(int t = 0; t < trials; t++)
        {
            setup.init();

            for(int nsteps = 0; nsteps < steps; nsteps++)
            {
                totalError += Math.abs(setup.getSpeedError());
                if(Math.abs(setup.getSpeedError()) < TOLERANCE) totalOK++;
                totalForce += Math.abs(setup.getForce());
                setup.update(controller.computeForceChange(setup.getSpeedError(), setup.getA()), TICK);
            }
        }
        
        return 1.0/(1.0+totalError/(steps*trials));
    }
    
    public void printStats(Evolvable evolvable)
    {
        double totalFitness = 0;
        double totalTotalError = 0;
        double totalTotalOK = 0;
        double totalTotalForce = 0;
        
        for(int i = 0; i < REPEATS; i++)
        {
            totalFitness += evaluate(evolvable);
            totalTotalError += totalError;
            totalTotalOK += totalOK;
            totalTotalForce += totalForce;
        }
        
        System.out.println("Overall fitness = " + totalFitness/REPEATS);
        System.out.println("Average absolute speed error = " + totalTotalError/(trials*steps*REPEATS));
        System.out.println("% of OK steps = " + totalTotalOK*100.0/(trials*steps*REPEATS));
        System.out.println("Average force used = " + totalTotalForce/(trials*steps*REPEATS));
    }

    private double totalError;
    private int totalOK;
    private double totalForce;
    
    private final CruiseControlSetup setup;      // the setup
    private final CruiseController controller;   // and the controller
    private final int steps;                     // number of time steps for each test
    private final int trials;                    // number of trials
  
    private static final double TOLERANCE = 3.0;
    private static final double TICK = 0.5;    // seconds
    private static final int REPEATS = 10;
}
