package CruiseControl;
/**
 * Cruise listener interface
 * 
 * @author CSG2341
 * @version 2015/2
 */

public interface CruiseListener
{
    public void update();
}
