package CruiseControl;

/**
 * Class to model a car
 * @author CSG2341
 * @version 2015/2
 */
public class Car
{
    public Car(double mass, double friction, double maxForce)
    {
        this.mass = mass;
        this.friction = friction;
        this.maxForce = maxForce;
        
        x = 0;
        v = 0;
    }
    
    public void setX(double x)
    {
        this.x = x;
    }
    
    public void setV(double v)
    {
        this.v = v;
    }
    
    public void update(double force, double theta, double tick)
    {
        force = Math.max(Math.min(force, maxForce), -maxForce);
        
        double newX = x + Math.cos(theta)*v*tick;
        double newV = v + ((force - getFriction(v))/mass - G*Math.sin(theta))*tick;
        
        x = newX;
        v = newV;
    }
    
    public double getX()
    {
        return x;
    }
    
    public double getV()
    {
        return v;
    }
    
    public double getMass()
    {
        return mass;
    }
    
    public double getFriction(double speed)
    {
        return friction*speed + Math.signum(speed)*AR*speed*speed;
    }
    
    public double getConstantSpeedForce(double theta, double target)
    {
        return mass*G*Math.sin(theta) + getFriction(target);
    }
    
    public double getMaxForce()
    {
        return maxForce;
    }
    
    public double getMaxAcceleration(double target)
    {
        return 2.0*G;
    }
    
    private double x;
    private double v;
    
    private final double mass; // kg
    private final double friction; // n/(m/s) - not including air friction
    private final double maxForce; // feasibility limit
    private final static double AR = 5;//1.2; // air resistance factor n/((m*m)/(s*s))
    private final static double G = 9.8; // m/s2
}
