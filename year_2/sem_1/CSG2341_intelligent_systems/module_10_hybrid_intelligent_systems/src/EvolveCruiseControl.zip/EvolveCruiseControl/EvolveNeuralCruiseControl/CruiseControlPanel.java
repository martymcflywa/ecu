package EvolveNeuralCruiseControl;
import CruiseControl.*;
import java.awt.*;
import java.awt.geom.*;
import javax.swing.*;

/**
 * GUI for a cruise control system
 * 
 * @author CSG2341
 * @version 2015/2
 */
public class CruiseControlPanel extends JPanel implements CruiseListener
{
    public CruiseControlPanel(CruiseControlSetup setup)
    {
        setPreferredSize(new Dimension(400, 200));
        
        this.setup = setup;
        
        setup.addListener(this);
    }
    
    public void update()
    {
        repaint();
    }
    
    @Override
    public void paintComponent(Graphics g)
    {
        super.paintComponent(g);
        
        setup.draw(g, new Rectangle2D.Double(0.0, getHeight(), getWidth(), getHeight()));
    }
    
    public void display()
    {
        JFrame viewer = new JFrame("Cruise Control");
        viewer.getContentPane().add(new JScrollPane(this));
        viewer.pack();
        viewer.setVisible(true);
    }

    private final CruiseControlSetup setup;
}
