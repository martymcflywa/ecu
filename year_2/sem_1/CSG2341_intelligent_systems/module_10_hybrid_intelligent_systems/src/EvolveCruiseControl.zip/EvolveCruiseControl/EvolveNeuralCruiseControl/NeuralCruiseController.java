
package EvolveNeuralCruiseControl;

import CruiseControl.*;
import au.edu.ecu.is.neural.MultiLayerPerceptron;

/**
 *
 * @author CSG2341
 * @version 2015/2
 */
public interface NeuralCruiseController extends CruiseController
{
    public MultiLayerPerceptron getMLP();    
}
