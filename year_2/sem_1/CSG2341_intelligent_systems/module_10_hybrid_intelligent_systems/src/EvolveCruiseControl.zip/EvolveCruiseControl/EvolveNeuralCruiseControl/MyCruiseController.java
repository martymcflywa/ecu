package EvolveNeuralCruiseControl;
import CruiseControl.*;
import au.edu.ecu.is.evolution.Evolvable;
import au.edu.ecu.is.neural.*;

import java.util.*;

/**
 * A cruise controller based on a multi-layer perceptron
 * 
 * @author CSG2341 
 * @version 2015/2
 */
public class MyCruiseController implements NeuralCruiseController
{
    public MyCruiseController(Car car, double targetSpeed)
    {
        mlp = new MultiLayerPerceptron
            (
                new int[]{2, 5, 1}, // 2 input, 5 hidden, 1 output
                new Random(), 0.1, 0.6, false // these learning parameters are irrelevant
            );
        
        this.targetSpeed = targetSpeed; 
        maxForce = car.getMaxForce();
        maxAcc = car.getMaxAcceleration(targetSpeed);

        inputs = new double[2];
    }

    public MultiLayerPerceptron getMLP()
    {
        return mlp;
    }
    
    public void load(Evolvable evolvable)
    {
        NeuronVectorGenome nvg = (NeuronVectorGenome)evolvable;
        nvg.copyToNeurons();
    }
    
    // and a method to compute the right change of force to apply
    public double computeForceChange(double speedError, double acceleration)
    {
        inputs[0] = speedError/targetSpeed;
        inputs[1] = acceleration/maxAcc;
        
        mlp.setInputs(inputs);
        return 2.0*maxForce*(mlp.getOutput(0) - 0.5);
    }
    
    private final MultiLayerPerceptron mlp;
    private final double[] inputs;

    private final double targetSpeed;
    private final double maxForce;
    private final double maxAcc;
}

