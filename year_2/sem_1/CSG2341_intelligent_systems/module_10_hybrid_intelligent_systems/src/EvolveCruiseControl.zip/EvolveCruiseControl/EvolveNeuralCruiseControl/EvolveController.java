package EvolveNeuralCruiseControl;
import CruiseControl.*;
import au.edu.ecu.is.evolution.*;
import au.edu.ecu.is.neural.*;

import java.util.*;

/**
 * A driver program to fine-tune a cruise controller by evolution
 * 
 * @author CSG2341
 * @version 2015/2
 */
public class EvolveController
{
    public static void main(String[] args)
    {
        EvolveController evolver = new EvolveController();
        
        try
        {
            evolver.go();
        }
        catch(Exception e)
        {
            e.printStackTrace(System.out);
        }
    }
    
    public void go() throws Exception
    {
        final double MASS = 1000.0;
        final double FRICTION = 10.0;
        final double MAXFORCE = 5000;
        final double MINH = 3.0;
        final double MAXH = 30.0;
        final double MINL = 300.0;
        final double MAXL = 500.0;
        final double WINDOWWIDTH = 1200.0;
        final double TARGET = 15.0;

        setup = new CruiseControlSetup(MASS, FRICTION, MAXFORCE, MINH, MAXH, MINL, MAXL, WINDOWWIDTH, TARGET);
        controller = new MyCruiseController(setup.getCar(), TARGET);
        mlp = controller.getMLP(); 
        evaluator = new CruiseEvaluator(setup, controller, STEPS, TRIALS);
        Random random = new Random();
               
        // parameters for the constructor of the Evolvable objects
        //
        // The Evolvable is a NeuronVectorGenome, which can be used to evolve weights for a neural network
        //
        Object[] constructorParams = 
            {
                mlp,    // the network set to use as a template
                random,
                MUTATIONRATE,
                EvolutionaryAlgorithm.ONEPOINT
            };
            
        ea = new GeneticAlgorithm
            (
                NeuronVectorGenome.class,
                constructorParams,
                POP,
                random,
                MUTATIONPROB,
                CROSSOVERPROB,
                evaluator,
                new GenerationsTerminator(GENERATIONS),
                new StochasticUniformSelector(random),
                true
            );

        // this listener is used to pop up a tester when the evolution is done        
        ea.addListener(new Reporter());
        
        //ea.test();        
        
        ea.display();
    }

    class Reporter implements EAListener
    {
        public void adviseInit(){}
        public void adviseUpdate(){}
        public void adviseDone()
        {
            try
            {
                evaluator.printStats(ea.getBestEver());
                
                NeuronVectorGenome nvg = (NeuronVectorGenome)ea.getBestEver();
                nvg.copyToNeurons();    // copies genome data to controller ruleset
                CruiseControlTest tester = new CruiseControlTest(setup, controller); 
                tester.display();
            }
            catch(Exception e)
            {
                System.out.println(e.getMessage());
                System.exit(0);
            }
        }
    }
    
    private static final int STEPS = 1000;
    private static final int TRIALS = 10;
    private static final int GENERATIONS = 2000;
    private static final int POP = 25;
    private static final double CROSSOVERPROB = 0.3;
    private static final double MUTATIONPROB = 0.1;
    private static final double MUTATIONRATE = 0.05;
        
    private EvolutionaryAlgorithm ea;
    private MultiLayerPerceptron mlp;
    private CruiseControlSetup setup;
    private NeuralCruiseController controller;
    private CruiseEvaluator evaluator;
}
