import au.edu.ecu.is.neural.*;

import java.util.*;

/**
 * A pendulum controller based on a multi-layer perceptron
 * 
 * @author (phi) 
 * @version (2003/2)
 */
public class MyPendulumController implements PendulumController
{
    public MyPendulumController()
    {
        mlp = new MultiLayerPerceptron
            (
                new int[]{2, 5, 1}, // 2 input, 5 hidden, 1 output
                new Random(), 0.1, 0.6, false // these learning parameters are irrelevant
            );
        
        inputs = new double[2];
    }

    public MultiLayerPerceptron getMLP()
    {
        return mlp;
    }
    
    // and a method to compute the right force to apply
    public double computeForce(double theta, double dtheta)
    {
        inputs[0] = theta;
        inputs[1] = dtheta;
        
        mlp.setInputs(inputs);
        return 3.0*(mlp.getOutput(0) - 0.5); // allows a range of +- 1.5N
    }
    
    private MultiLayerPerceptron mlp;
    private double[] inputs;
}
