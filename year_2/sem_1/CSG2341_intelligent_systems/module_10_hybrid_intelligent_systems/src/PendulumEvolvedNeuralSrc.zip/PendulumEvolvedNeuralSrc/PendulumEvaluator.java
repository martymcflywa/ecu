import au.edu.ecu.is.evolution.*;
import au.edu.ecu.is.neural.*;

import java.util.*;

/**
 * An evaluator for an evolutionary algorithm to evolve an inverted pendulum controller.
 * 
 * @author (phi) 
 * @version (2003/2)
 */
public class PendulumEvaluator extends Evaluator
{
    PendulumEvaluator(InvertedPendulum pendulum, PendulumController controller, int reps)
    {
        this.pendulum = pendulum;
        this.controller = controller;
        this.reps = reps;
    }
    
    // estimate the fitness of a controller with evolved shapes and other parameters
    public double evaluate(Evolvable evolvable)
    {
        // load the parameters into the controller
        NeuronVectorGenome genome = (NeuronVectorGenome)evolvable;
        genome.copyToNeurons();   

        double fitness = 0.0;
        int totalSteps = 0;
        double totalTheta = 0.0;
        double totalDtheta = 0.0;
        
        // simulate the pendulum for STEPS timesteps, reps times
        for(int i = 0; i < reps; i++)
        {
            pendulum.tap(-0.5 + random.nextDouble());
            int steps = 0;
            while(!pendulum.isStopped() && steps < STEPS)
            {
                pendulum.update(controller.computeForce(pendulum.getTheta(), pendulum.getDtheta()), TICK);
                totalTheta += Math.abs(pendulum.getTheta());
                totalDtheta += Math.abs(pendulum.getDtheta());
                totalSteps++;
                steps++;
            }
            
            fitness += Math.max(0, steps - STEPS/10*Math.abs(pendulum.getTheta()));
        }
        
        return totalSteps/totalTheta;
        //return totalDtheta; // lean over?
        //return totalTheta; // fall slowly?
        //return totalSteps; // last as long as you can?
        //return fitness;    // balance between staying vertical and staying up a long time
    }
    
    private InvertedPendulum pendulum;      // the pendulum
    private PendulumController controller;  // and its controller
    private int reps;                       // number of times to test the controller to estimate fitness

    private static final int STEPS = 1000;   // the number of time sets for each test
    
    private static final double TICK = 0.002;    // seconds
    private Random random = new Random();
}
