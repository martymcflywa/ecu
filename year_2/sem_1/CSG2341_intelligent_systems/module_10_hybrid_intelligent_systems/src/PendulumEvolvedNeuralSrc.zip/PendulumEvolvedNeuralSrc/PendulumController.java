import au.edu.ecu.is.neural.*;

/**
 * Write a description of class PendulumController here.
 * 
 * @author (your name) 
 * @version (a version number or a date)
 */
public interface PendulumController
{
    public MultiLayerPerceptron getMLP();

    public double computeForce(double theta, double dtheta);
}
