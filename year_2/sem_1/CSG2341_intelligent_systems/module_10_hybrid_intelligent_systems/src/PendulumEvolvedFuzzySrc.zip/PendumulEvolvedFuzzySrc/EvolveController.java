import au.edu.ecu.is.evolution.*;
import au.edu.ecu.is.fuzzy.*;

import java.util.*;

/**
 * A driver program to fine-tune a pendulum controller by evolution
 * 
 * @author (phi) 
 * @version (2003/2)
 */
public class EvolveController
{
    public static void main(String[] args)
    {
        EvolveController evolver = new EvolveController();
        
        try
        {
            evolver.go();
        }
        catch(Exception e)
        {
            e.printStackTrace(System.out);
        }
    }
    
    public void go() throws Exception
    {
        pendulum = new InvertedPendulum(1.0, 0.05, 20);
        controller = new MyPendulumController();        
        ruleset = controller.getRuleSet();                
        Random random = new Random();
               
        // parameters for the constructor of the Evolvable objects
        //
        // The Evolvable is a FuzzyRuleSetGenome, which can be used to evolve parameters for a FuzzyRuleSet
        //
        Object[] constructorParams = 
            {
                ruleset,    // the rule set to use as a template
                random,
                new Double(MUTATIONRATE),
                new Integer(EvolutionaryAlgorithm.ONEPOINT)
            };
            
        ea = new GeneticAlgorithm
            (
                FuzzyRuleSetGenome.class,
                constructorParams,
                POP,
                random,
                MUTATIONPROB,
                CROSSOVERPROB,
                new PendulumEvaluator(pendulum, controller, REPS),
                new GenerationsTerminator(GENERATIONS),
                new StochasticUniformSelector(random),
                true
            );

        // this listener is used to pop up a tester when the evolution is done        
        ea.addListener(new Reporter());
        
        //ea.test();        
        
        ea.display();
    }

    class Reporter implements EAListener
    {
        public void adviseInit(){}
        public void adviseUpdate(){}
        public void adviseDone()
        {
            try
            {
                FuzzyRuleSetGenome frs = (FuzzyRuleSetGenome)ea.getBestEver();
                frs.copyToRuleSet();    // copies genome data to controller ruleset
                PendulumTest tester = new PendulumTest(pendulum, controller);
                tester.display();
            }
            catch(Exception e)
            {
                System.out.println(e.getMessage());
                System.exit(0);
            }
        }
    }
    
    private static final int REPS = 10;
    private static final int GENERATIONS = 2000;
    private static final int POP = 25;
    private static final double CROSSOVERPROB = 0.7;
    private static final double MUTATIONPROB = 0.02;
    private static final double MUTATIONRATE = 0.02;
        
    private EvolutionaryAlgorithm ea;
    private FuzzyRuleSet ruleset;
    private InvertedPendulum pendulum;
    private PendulumController controller;
}
