import au.edu.ecu.is.fuzzy.*;

/**
 * Example solution for a fuzzy controller for an inverted pendulum.
 * 
 * Other solutions (maybe simpler and better) are possible
 * 
 * @author (phi) 
 * @version (2003/2)
 */
public class MyPendulumController implements PendulumController
{
    public MyPendulumController() throws FuzzyException
    {
        // create fuzzy variable for pendulum angle
        theta = new FuzzyVariable("theta", "radians", -Math.PI*0.5, Math.PI*0.5, 2);
        
        FuzzySet wayLeft = new FuzzySet("way left", -Math.PI*0.5, -Math.PI*0.5, -Math.PI*0.3, -Math.PI*0.1);
        FuzzySet left = new FuzzySet("left", -Math.PI*0.15, -Math.PI*0.09, -Math.PI*0.09, -Math.PI*0.03);
        FuzzySet slightlyLeft = new FuzzySet("slightly left", -Math.PI*0.1, -Math.PI*0.05, -Math.PI*0.05, -Math.PI*0.005);
        FuzzySet straight = new FuzzySet("straight", -Math.PI*0.01, -Math.PI*0.01, Math.PI*0.01, Math.PI*0.01);
        FuzzySet slightlyRight = new FuzzySet("slightly right", Math.PI*0.02, Math.PI*0.1, Math.PI*0.1, Math.PI*0.15);
        FuzzySet right = new FuzzySet("right", Math.PI*0.15, Math.PI*0.2, Math.PI*0.2, Math.PI*0.3);
        FuzzySet wayRight = new FuzzySet("way right", Math.PI*0.2, Math.PI*0.3, Math.PI*0.5, Math.PI*0.5);
        
        theta.add(wayLeft);
        theta.add(left);
        theta.add(slightlyLeft);
        theta.add(straight);
        theta.add(slightlyRight);
        theta.add(right);
        theta.add(wayRight);
        
        // and one for the rate of change of the angle
        double maxLeft = -20.0*Math.PI;
        double maxRight = 20.0*Math.PI;
        dtheta = new FuzzyVariable("dtheta", "radians/sec", maxLeft, maxRight, 2);
        
        FuzzySet fastLeft = new FuzzySet("fast left", maxLeft, maxLeft, 0.5*maxLeft, 0.25*maxLeft);
        FuzzySet slowLeft = new FuzzySet("slow left", 0.3*maxLeft, 0.1*maxLeft, 0.0, 0.0);
        FuzzySet still = new FuzzySet("still", 0.1*maxLeft, 0.0, 0.0, 0.1*maxRight);
        FuzzySet slowRight = new FuzzySet("slow right", 0.0, 0.0, 0.1*maxRight, 0.3*maxRight);
        FuzzySet fastRight = new FuzzySet("fast right", 0.25*maxRight, 0.5*maxRight, maxRight, maxRight);
        
        dtheta.add(fastLeft);
        dtheta.add(slowLeft);
        dtheta.add(still);
        dtheta.add(slowRight);
        dtheta.add(fastRight);
        
        // and create a fuzzy variable to represent the control variable - force to apply
        final double MAX = 1.5;
        force = new FuzzyVariable("force", "newtons", -MAX, MAX, 2);
        
        // now construct a matrix of fuzzy sugeno-type rules
        rules = new SugenoRuleSet();
        
        FuzzySet[] dthetaSets = {fastLeft, slowLeft, still, slowRight, fastRight};
        FuzzySet[] thetaSets = {wayLeft, left, slightlyLeft, straight, slightlyRight, right, wayRight};
        
        double[][] forces =
            {
                {-MAX,      -MAX,     -0.5*MAX,  -0.25*MAX,    0.0,        0.0,     0.05*MAX},
                {-MAX,      -MAX,     -0.25*MAX, -0.125*MAX,   0.0,        0.5*MAX, MAX},
                {-MAX,      -MAX,     -0.25*MAX, 0.0,          0.25*MAX,   MAX,     MAX},
                {-MAX,      -0.5*MAX, 0.0,       0.125*MAX,    0.25*MAX,   MAX,     MAX},
                {-0.05*MAX,  0.0,     0.0,       0.25*MAX,     0.5*MAX,    MAX,     MAX}
            };
       
       rules.addRuleMatrix(
            dtheta, dthetaSets,
            theta, thetaSets,
            force, forces);   
            
//        (new FuzzyRuleMatrixPanel(rules,
//             dtheta, dthetaSets,
//             theta, thetaSets,
//             force)).display();
    }
    
    // access methods for the fuzzy objects
    
    public FuzzyRuleSet getRuleSet()
    {
        return rules;
    }

    public FuzzyVariable getTheta()
    {
        return theta;
    }
    
    public FuzzyVariable getDtheta()
    {
        return dtheta;
    }
    
    public FuzzyVariable getForce()
    {
        return force;
    }
    
    // and a method to compute the right force to apply
    public double computeForce(double theta, double dtheta)
    {
        try
        {
            this.theta.setValue(theta);
            this.dtheta.setValue(dtheta);
            
            rules.update();
            
            return force.getValue();
        }
        catch(FuzzyException e)
        {
            //System.out.println(e.getMessage());
            return 0.0;
        }
    }
    
    private SugenoRuleSet rules;
    private FuzzyVariable theta;
    private FuzzyVariable dtheta;
    private FuzzyVariable force;
}
