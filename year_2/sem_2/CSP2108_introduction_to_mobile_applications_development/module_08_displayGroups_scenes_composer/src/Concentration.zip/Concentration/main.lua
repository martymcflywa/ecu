-----------------------------------------------------------------------------------------
--
-- main.lua
--
-----------------------------------------------------------------------------------------

local composer = require "composer"

-- load in and play an annoying background track
local backgroundMusic = audio.loadStream('midnight-ride.mp3')
audio.play(backgroundMusic, { channel = 1, loops = -1, fadein = 5000})

-- 4 background images to cycle through
local backgrounds = {
	'prometheus1.png',
	'prometheus2.png',
	'prometheus3.png',
	'prometheus4.png',
}
-- allow scenes to share this information
composer.setVariable("backgrounds", backgrounds)

-- scene loading options
local options = {
    effect = "fade",
    time = 1000,
    params = {
        sceneNumber = 1
    }
}

-- load first screen
composer.gotoScene( "gameScene", options )