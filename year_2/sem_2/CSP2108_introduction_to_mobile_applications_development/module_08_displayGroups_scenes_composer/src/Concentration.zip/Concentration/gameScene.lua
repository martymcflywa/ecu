-- ---------------
-- gameScene.lua
-- ---------------

local composer = require( "composer" )

local scene = composer.newScene()

-- -----------------------------------------------------------------------------------
-- Code outside of the scene event functions below will only be executed ONCE unless
-- the scene is removed entirely (not recycled) via "composer.removeScene()"
-- -----------------------------------------------------------------------------------

local sceneNumber = 0

-- card sizes and spacing
local cardImageFile = '200px-Card_back_01.png'
local cardWidth = 80 -- these determine how many cards fit across the page
local cardHeight = 120 -- keep the ratio 80/120
local fontSize = 28 -- might need to adjust if you make the cards smaller
local spacing = 10

-- background image
local backgroundImage
--local backgroundImageFile = 'prometheus1.png'

-- keeping track of game state
local cards = {}
local card1, card2
local ready = true
local pairsNotFound

-- audio
local tapSound, correctSound
--local tapSound = audio.loadSound('button-16.wav')
--local correctSound = audio.loadSound('magic-chime-02.wav')
 
local function makeBackground(group, sceneNumber)
	local backgrounds = composer.getVariable("backgrounds")

	backgroundImage = display.newImage(backgrounds[sceneNumber])
	backgroundImage.x = display.contentWidth/2
	backgroundImage.y = display.contentHeight/2
	backgroundImage.xScale = display.contentWidth/backgroundImage.width
	backgroundImage.yScale = display.contentHeight/backgroundImage.height
	
	group:insert(1, backgroundImage)
end

local function revert()
	if card1.value ~= 0 then
		card1.isVisible = true
	end
	card1 = nil
	if card2.value ~= 0 then
		card2.isVisible = true
	end
	card2 = nil
	ready = true
end

local function pairFound()
	audio.play(correctSound)
	card1.rect.isVisible = false
	card1.textObject.isVisible = false
	card1 = nil
	card2.rect.isVisible = false
	card2.textObject.isVisible = false
	card2 = nil
	ready = true
end

local function allDone()
	local nScenes = #composer.getVariable("backgrounds")
	
	local nextScene = sceneNumber < nScenes and sceneNumber+1 or 1
	
    local options = {
		effect = "zoomInOut",
		time = 2000,
		params = {
			sceneNumber = nextScene
		}
	}
	
	local currScene = composer.getSceneName( "current" )
	composer.gotoScene( currScene, options )
end

local function cardListener(event)
	if not ready then
		return true
	end
	if event.phase == "began" then
		event.target.isVisible = false
		audio.play(tapSound)
		if card1 == nil then
			card1 = event.target
		else
			card2 = event.target
			if card1.value == card2.value then
				ready = false
				timer.performWithDelay(1000, pairFound)
				pairsNotFound = pairsNotFound-1
				if pairsNotFound == 0 then
					ready = false
					timer.performWithDelay(1000, allDone)
				end
			else
				ready = false
				timer.performWithDelay(1000, revert)
			end
		end
		return true
	end
end

function makeCards(group)
	local columns = math.floor(display.contentWidth/(cardWidth+spacing))
	local left = cardWidth/2 + (display.contentWidth - columns*(cardWidth+spacing) + spacing)/2

	local rows = math.floor(display.contentHeight/(cardHeight+spacing))
	local top = cardHeight/2 + (display.contentHeight - rows*(cardHeight+spacing) + spacing)/2

	local numberOfCards = 0
	for row = 1, rows do
		for column = 1, columns do
			local x = left + (column-1)*(cardWidth+spacing)
			local y = top + (row-1)*(cardHeight+spacing)

			local card = display.newImageRect(cardImageFile, cardWidth, cardHeight)
			card.x = x
			card.y = y
			card:addEventListener("touch", cardListener)

			numberOfCards = numberOfCards+1
			cards[numberOfCards] = card
			
			group:insert(card)
		end
	end
end

function setCard(group, card, value)
	local x = card.x
	local y = card.y

	local rect = display.newRect(x-cardWidth/2, y-cardHeight/2, cardWidth, cardHeight)
	rect:setFillColor(0.7,0.7,0.6)
	rect.anchorX = 0
	rect.anchorY = 0
	
	group:insert(rect)

	local textOptions = {
		text = value,
		font = native.systemFont,
		fontSize = fontSize,
	}
	local textObject = display.newText(textOptions)
	textObject:setTextColor(0.2,0.2,0.2)
	textObject.x = x
	textObject.y = y
	
	group:insert(textObject)

	card.value = value

	card.rect = rect
	card.textObject = textObject

	card:toFront()
end

function makeFaces(group)
	-- set all card values to 0
	for k,v in pairs(cards) do
		v.value = 0
		v.isVisible = true
		if v.rect ~= nil then
			v.rect:removeSelf()
			v.rect = nil
		end
		if v.textObject ~= nil then
			v.textObject:removeSelf()
			v.textObject = nil
		end
	end

	pairsNotFound = 0
	-- now loop until all pairs are made
	local cardsRemaining = #cards
	while cardsRemaining > 1 do
		-- pick a value
		local value = math.random(1, 12)

		-- find a card without a value
		local card = cards[math.random(1, #cards)]
		while card.value ~= 0 do
			card = cards[math.random(1, #cards)]
		end
		-- set the card's value
		setCard(group, card, value)
		cardsRemaining = cardsRemaining-1

		-- find another card without a value
		card = cards[math.random(1, #cards)]
		while card.value ~= 0 do
			card = cards[math.random(1, #cards)]
		end
		-- set it to the same value
		setCard(group, card, value)	
		cardsRemaining = cardsRemaining-1

		pairsNotFound = pairsNotFound+1
	end

	ready = true
end

-- -----------------------------------------------------------------------------------
-- Scene event functions
-- -----------------------------------------------------------------------------------

-- create()
function scene:create( event )

    -- Code here runs when the scene is first created but has not yet appeared on screen
	tapSound = audio.loadSound('button-16.wav')
	correctSound = audio.loadSound('magic-chime-02.wav')

    -- Assign "self.view" to local variable "sceneGroup" for easy reference
    local sceneGroup = self.view

	makeCards(sceneGroup) 
end


-- show()
function scene:show( event )

    local sceneGroup = self.view
    local phase = event.phase
    local params = event.params

    if ( phase == "will" ) then
        -- Code here runs when the scene is still off screen (but is about to come on screen)
        sceneNumber = params.sceneNumber
		makeBackground(sceneGroup, sceneNumber)
		makeFaces(sceneGroup) 
		
    elseif ( phase == "did" ) then
        -- Code here runs when the scene is entirely on screen

    end
end


-- hide()
function scene:hide( event )

    local sceneGroup = self.view
    local phase = event.phase

    if ( phase == "will" ) then
        -- Code here runs when the scene is on screen (but is about to go off screen)

    elseif ( phase == "did" ) then
        -- Code here runs immediately after the scene goes entirely off screen
        
        backgroundImage:removeSelf()
        backgroundImage = nil
    end
end


-- destroy()
function scene:destroy( event )

	audio.stop(tapSound)
	audio.stop(correctSound)
	
	audio.displose(tapSound)
	tapSound = nil
	
	audio.dispose(correctSound)
	correctSound = nil
	
    local sceneGroup = self.view
    -- Code here runs prior to the removal of scene's view

end


-- -----------------------------------------------------------------------------------
-- Scene event function listeners
-- -----------------------------------------------------------------------------------
scene:addEventListener( "create", scene )
scene:addEventListener( "show", scene )
scene:addEventListener( "hide", scene )
scene:addEventListener( "destroy", scene )
-- -----------------------------------------------------------------------------------

return scene

