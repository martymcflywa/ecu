-----------------------------------------------------------------------------------------
--
-- sliderScene.lua
--
-- This is the scene in which questions are asked and answers checked
--
-----------------------------------------------------------------------------------------

local composer = require( "composer" )

local scene = composer.newScene()

-- -----------------------------------------------------------------------------------
-- Code outside of the scene event functions below will only be executed ONCE unless
-- the scene is removed entirely (not recycled) via "composer.removeScene()"
-- -----------------------------------------------------------------------------------

-- load in slider
local slider = require( "slider" )

local SIZE = slider.SIZE

-- -----------------------------------------------------------------------------------
-- user interface stuff
-- -----------------------------------------------------------------------------------

local widget = require( "widget" )

-- sounds initialised in scene:create()
local soundTable = {}

-- image sheet for background image
local IMAGE_SIZE = 750 -- change this if using a different sized background image
local options =
{
    width = IMAGE_SIZE/SIZE,
    height = IMAGE_SIZE/SIZE,
    numFrames = SIZE*SIZE
}
local sheet = {} -- initialised in scene:create()

-- an array of "tiles"

local tiles = {} -- tiles created in makeTiles(), called in scene:create()

-- moves tiles back to starting positions
local function resetTiles()
	for i = 1, #tiles do
		tiles[i].row = tiles[i].homeRow
		tiles[i].column = tiles[i].homeColumn
		tiles[i].x = 25 + (tiles[i].column-1)*54
		tiles[i].y = 25 + (tiles[i].row-1)*54
	end
end

-- get the tile currently in this row and column
local function getTile( row, column )
	index = slider:getTile( row, column )
	if index == 0 then
		return nil
	else
		return tile[index]
	end
end

-- do the moves for selecting this tile
-- call with sound == true if sound is wanted
local function doMovesForTile(tile, sound)
	-- first figure out which tiles should move to where
	local moves = slider:getMoves(tile.row, tile.column)
	-- then if anything is supposed to move, do it
	if moves then
		-- update the game info
		slider:doMoves()
		-- make noise if needed
		if sound then audio.play(soundTable.slideSound) end
		-- move the tiles on the display
		for m, move in pairs(moves) do
			local moveTile = tiles[move.from.index]
			moveTile.row = move.to.row
			moveTile.column = move.to.column
			transition.to(moveTile, {x = 25+(move.to.column-1)*54, y = 25+(move.to.row-1)*54, time = 100})
		end
	end
end

-- do the moves for selecting this tile number
local function doMovesForIndex(index, sound)
	doMovesForTile(tiles[index], sound)
end

-- make a tile
local function makeTile( row, column )
	tile = display.newImageRect(sheet, 1 + (row-1)*SIZE + (column-1), 54, 54)
	tile.anchorX = 0
	tile.anchorY = 0
	
	tile.x = 25 + (column-1)*54
	tile.y = 25 + (row-1)*54
	
	tile.homeRow = row
	tile.homeColumn = column
	
	tile.row = row
	tile.column = column
	
	tile.strokeWidth = 3
	tile:setStrokeColor(0, 0, 1)
	
	return tile
end

-- create this tiles and insert in a display group
local function makeTiles(group)
	for row = 1, SIZE do
		for column = 1, SIZE do
			if row ~= SIZE or column ~= SIZE then
				local tile = makeTile(row, column)
				group:insert(tile)
				tiles[#tiles+1] = tile
			end
		end
	end
end

-- restart by jumbling the tiles
local function jumbleTiles( event )
	slider:reset()
	resetTiles()
	
	for i = 1, 100 do
		doMovesForIndex(math.random(#tiles), false)
	end
end

-- -----------------------------------------------------------------------------------
-- Scene event functions
-- -----------------------------------------------------------------------------------

-- create()
function scene:create( event )

    local sceneGroup = self.view
    -- Code here runs when the scene is first created but has not yet appeared on screen
	
	-- load in sounds
	soundTable = {
		slideSound = audio.loadSound( "sounds/slide.wav" ),
	}

	-- load in image sheet
	sheet = graphics.newImageSheet( "images/felix.jpg", system.ResourceDirectory, options )
	
	-- create the border
	local top = display.newRect(20, 20, 280, 5)
	top.anchorX = 0
	top.anchorY = 0
	top:setFillColor(0.5, 0.5, 0)
	sceneGroup:insert(top)
	local bottom = display.newRect(20, 295, 280, 5)
	bottom.anchorX = 0
	bottom.anchorY = 0
	bottom:setFillColor(0.5, 0.5, 0)
	sceneGroup:insert(bottom)
	local left = display.newRect(20, 20, 5, 280)
	left.anchorX = 0
	left.anchorY = 0
	left:setFillColor(0.5, 0.5, 0)
	sceneGroup:insert(left)
	local right = display.newRect(295, 20, 5, 280)
	right.anchorX = 0
	right.anchorY = 0
	right:setFillColor(0.5, 0.5, 0)
	sceneGroup:insert(right)
	
	--create the inside
	inside = display.newRect(25, 25, 270, 270)
	inside.anchorX = 0
	inside.anchorY = 0
	inside:setFillColor(0.2, 0.2, 0)
	sceneGroup:insert(inside)
	
	--add the tiles
	makeTiles(sceneGroup)
	
end

-- show()
function scene:show( event )

    local sceneGroup = self.view
    local phase = event.phase

    if ( phase == "will" ) then
        -- Code here runs when the scene is still off screen (but is about to come on screen)

    elseif ( phase == "did" ) then
        -- Code here runs when the scene is entirely on screen

		jumbleTiles()
    end
end

-- hide()
function scene:hide( event )

    local sceneGroup = self.view
    local phase = event.phase

    if ( phase == "will" ) then
        -- Code here runs when the scene is on screen (but is about to go off screen)

    elseif ( phase == "did" ) then
        -- Code here runs immediately after the scene goes entirely off screen

    end
end

-- destroy()
function scene:destroy( event )

    local sceneGroup = self.view
    -- Code here runs prior to the removal of scene's view

	-- clean up audio stuff
	audio.stop()

	for s,v in pairs( soundTable ) do
		audio.dispose( soundTable[s] )
		soundTable[s] = nil
	end
end

-- -----------------------------------------------------------------------------------
-- Scene event function listeners
-- -----------------------------------------------------------------------------------
scene:addEventListener( "create", scene )
scene:addEventListener( "show", scene )
scene:addEventListener( "hide", scene )
scene:addEventListener( "destroy", scene )
-- -----------------------------------------------------------------------------------

return scene