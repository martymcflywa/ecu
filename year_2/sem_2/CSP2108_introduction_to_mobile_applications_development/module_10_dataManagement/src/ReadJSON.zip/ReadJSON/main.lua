-----------------------------------------------------------------------------------------
--
-- main.lua
--
-----------------------------------------------------------------------------------------

local json = require("json")

-----------------------------------------------------------------------------------------
-- borrowed this from https://coronalabs.com/blog/2014/09/02/tutorial-printing-table-contents/
-- prints out the contents of a table

function print_r ( t )  
    local print_r_cache={}
    local function sub_print_r(t,indent)
        if (print_r_cache[tostring(t)]) then
            print(indent.."*"..tostring(t))
        else
            print_r_cache[tostring(t)]=true
            if (type(t)=="table") then
                for pos,val in pairs(t) do
                    if (type(val)=="table") then
                        print(indent.."["..pos.."] => "..tostring(t).." {")
                        sub_print_r(val,indent..string.rep(" ",string.len(pos)+8))
                        print(indent..string.rep(" ",string.len(pos)+6).."}")
                    elseif (type(val)=="string") then
                        print(indent.."["..pos..'] => "'..val..'"')
                    else
                        print(indent.."["..pos.."] => "..tostring(val))
                    end
                end
            else
                print(indent..tostring(t))
            end
        end
    end
    if (type(t)=="table") then
        print(tostring(t).." {")
        sub_print_r(t,"  ")
        print("}")
    else
        sub_print_r(t,"  ")
    end
    print()
end
------------------------------------------------------------------------------------------

local path = system.pathForFile("olympicData.json", system.ResourceDirectory)

---[[

local file, errorString = io.open( path , "r" )

if not file then
	print( "File error: " .. errorString )
else
	local contents = file:read( "*a" )
	io.close( file )

	local summerOlympics, pos, msg = json.decode( contents )
	if not summerOlympics then
		print( "Decode failed at "..tostring(pos)..": "..tostring(msg) )
	else
		print_r( summerOlympics )
	end
end

--]]

--[[
-- this is supposed to work, but doesn't seem to

local summerOlympics, pos, msg = json.decodeFile( path )

if not summerOlympics then
    print( "Decode failed at "..pos..": "..msg )
else
		print_r( summerOlympics )
end
--]]




