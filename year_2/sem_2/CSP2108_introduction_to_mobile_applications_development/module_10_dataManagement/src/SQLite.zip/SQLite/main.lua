-----------------------------------------------------------------------------------------
--
-- main.lua
--
-- Example program demonstrating SQLite - based on https://coronalabs.com/blog/2012/04/03/tutorial-database-access-in-corona/
--
-----------------------------------------------------------------------------------------

local sqlite3 = require( "sqlite3" )
 
-- creating a DB

local path = system.pathForFile( "data.db", system.DocumentsDirectory )
local db, dbErrorCode, dbError = sqlite3.open( path )

-- should check that db is not nil. For demo purposes, we won't check errors

-- for demo : start from scratch each time
local dbErrorCode = db:exec( [[DROP TABLE test;]] )

-- creating a table

local tablesetup = [[CREATE TABLE IF NOT EXISTS test (id INTEGER PRIMARY KEY autoincrement, name, description, website);]]
dbErrorCode = db:exec( tablesetup )

-- inserting rows

local insertQuery = [[INSERT INTO test VALUES (NULL, 'John Doe','This is an unknown person.', 'http://www.example.com/');]]
dbErrorCode = db:exec( insertQuery )

-- table to DB

local people =
{
    {
        name = "John Doe",
        description = "This is an unknown person.",
        website = "http://www.example.com/"
    },
    {
        name = "Jane Doe",
        description = "The wife of an unknown person.",
        website = "http://www.example2.com/"
    },
    {
        name = "Oscar",
        description = "Green guy lives in trash can.",
        website = "http://www.example3.com/"
    }
}
 
for i = 1,#people do
    local q = [[INSERT INTO test VALUES (NULL, ']] .. people[i].name .. [[',']] .. 
    	people[i].description .. [[', ']] .. people[i].website .. [[');]]
    dbErrorCode = db:exec( q )
end

-- updating

local q = [[UPDATE test SET name='Grouch' WHERE id=3;]]
dbErrorCode = db:exec( q )

-- deleting a row

local q = [[DELETE FROM test WHERE id=1;]]
dbErrorCode = db:exec( q )

-- retrieving
 
local people = {}  -- Begins empty
 
for row in db:nrows("SELECT * FROM test") do
    print( "Row " .. row.id .. " : " .. row.name )
 
    -- Create table at the next available array index
    people[#people+1] =
    {
        name = row.name,
        description = row.description,
        website = row.website
    }
end

-- closing

local function onSystemEvent( event )
    if ( event.type == "applicationExit" ) then
        if ( db and db:isopen() ) then
            db:close()
        end
    end
end
Runtime:addEventListener( "system", onSystemEvent )