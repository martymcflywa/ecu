-----------------------------------------------------------------------------------------
--
-- main.lua
--
-----------------------------------------------------------------------------------------
local json = require("json")

local summerOlympics = {
	{ year = 1896, city = "Athens", country = "Greece" }, 
	{ year = 1900, city = "Paris", country = "France" }, 
	{ year = 1904, city = "St Louis", country = "USA"},
}

local summerOlympicsString = json.encode(summerOlympics)

print(summerOlympicsString)

--[[

This is the output, with newlines inserted

[{"city":"Athens","year":1896,"country":"Greece"},
{"city":"Paris","year":1900,"country":"France"},
{"city":"St Louis","year":1904,"country":"USA"}]

--]]

