-----------------------------------------------------------------------------------------
--
-- main.lua
--
-----------------------------------------------------------------------------------------

-- Create a native map view
local myMap = native.newMapView( 20, 20, 280, 360 )
myMap.x = display.contentCenterX
myMap.y = display.contentCenterY

-- Display map as vector drawings of streets (other options are "satellite" and "hybrid")
myMap.mapType = "standard"

-- Initialize map to a real location
myMap:setCenter( -31.752946, 115.773322 )


-- add a marker

-- a listener if you want one
-- called when the user taps on the marker
local function markerListener( event )
-- event has fields markerID, latitude and longitude
end

-- options if you want them
local markerOptions = {
	title = "Joondalup Train Station",
	subtitle = "Catch the shuttle to/from here",
	listener = markerListener,
	imageFile = "Joondalup_station_at_night.jpg"
}
myMap:addMarker( -31.744790, 115.767446 , markerOptions )

local function locationHandler( event )

    if ( event.isError ) then
        print( "Map Error: " .. event.errorMessage )
    else
        print( "The specified string is at: " .. event.latitude .. "," .. event.longitude )
    end

end

myMap:requestLocation( "ECU Village Joondalup", locationHandler )
--> The specified string is at: -31.7513581,115.7764679

local function whatHandler( event )

    if ( event.isError ) then
        print( "Map Error: " .. event.errorMessage )
    else
        print( "Nearest location: " .. event.city .. 
        	", " .. event.country ) 
    end

end

local function mapLocationListener( event )
    print( "The tapped location is in: " .. event.latitude .. ", " .. event.longitude )
end

myMap:addEventListener( "mapLocation", mapLocationListener )


myMap:nearestAddress( -31.744790, 115.767446, whatHandler )
--> Nearest location: Joondalup, Australia

local attempts = 0

local function userLocationHandler( event )

    local currentLocation = myMap:getUserLocation()

    if ( currentLocation.errorCode or ( currentLocation.latitude == 0 and currentLocation.longitude == 0 ) ) then
        print(currentLocation.errorMessage)

        attempts = attempts + 1

        if ( attempts > 10 ) then
            native.showAlert( "No GPS Signal", "Can't sync with GPS.", { "Okay" } )
        else
            timer.performWithDelay( 1000, userLocationHandler )
        end
    else
        print("Current location: " .. currentLocation.latitude .. "," .. currentLocation.longitude)
    end
end

attempts = 0; userLocationHandler()
attempts = 0; timer.performWithDelay( 5000, userLocationHandler )
