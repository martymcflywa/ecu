-----------------------------------------------------------------------------------------
--
-- main.lua
--
-----------------------------------------------------------------------------------------

--[[

if not system.openURL("http://www.coronalabs.com") then
	native.showAlert("Corona Networking", "can't open http://www.coronalabs.com")
end

if not system.openURL("mailto:phi@philiphingston.com") then
	native.showAlert("Corona Networking", "can't open mailto:phi@philiphingston.com")
end

if not system.openURL("tel:0423-592-382") then
	native.showAlert("Corona Networking", "can't open tel:0423-592-382")
end

--]]

--[[ requires

    android =
    {
        usesPermissions =
        {
            "android.permission.CALL_PHONE",
        },
    },
--]]

--[[

local function networkListener( event )

    if ( event.isError ) then
        print( "Network error: ", event.response )
    else
        print ( "RESPONSE: " .. event.response )
    end
end

-- Access JSON placeholder
network.request( "http://jsonplaceholder.typicode.com/posts?userId=1", "GET", networkListener )

--]]

--[[

local function networkListener( event )
    if ( event.isError ) then
        print( "Network error: ", event.response )
    elseif ( event.phase == "ended" ) then
        print( "Download complete, total bytes transferred: " .. event.bytesTransferred )
    end
end

local params = {}

-- Tell network.request() that we want the "began" and "progress" events:
-- params.progress = "download"

-- Tell network.request() that we want the output to go to a file:
params.response = {
    filename = "corona.jpg",
    baseDirectory = system.DocumentsDirectory
}

network.request( "http://docs.coronalabs.com/images/simulator/image-mask-base2.png", "GET", networkListener,  params )

--]]

local socket = require( "socket" )

-- Connect to the client
local client = socket.connect( "www.ecu.edu.com", 80 )
-- Get IP and port from client
local ip, port = client:getsockname()

-- Print the IP address and port to the terminal
print( "IP Address:", ip )
print( "Port:", port )
